
.tuningfixedtauepsilon <- function(method, A, Alabels, prior, tau, sigma2inv_init, z_init, thetas_init, nruns_samp, upper = 2, lower = 0, targetrange = c(0.8, 0.85), d = 2){
  epsmethods <- c("split HMC", "split HMC + firefly", "leapfrog HMC", "leapfrog HMC + firefly", "nuts", "nuts + firefly")
  if(!(method %in% epsmethods)){
    strr <- paste("Method must be one of ", epsmethods[1])
    for(i in 2:length(epsmethods)){
      strr <- paste(strr, epsmethods[i], sep = ", ")
    }
    stop(strr)
  }

  return(.tuneepshelp4(method, A, Alabels, prior, z_init, tau, sigma2inv_init,thetas_init, nruns_samp, upper = upper, lower = lower, targetrange = targetrange))
}

.tuningfixedtauzrw <- function(method, A, Alabels, prior, tau, sigma2inv_init, z_init,thetas_init, nruns_samp, upper = 10, lower = 0, targetrange = c(0.2, 0.3), d = 2){
  metmethods <- c("Metropolis within Gibbs", "Metropolis within Gibbs + firefly")
  if(!(method %in% metmethods)){
    strr <- paste("Method must be one of ", metmethods[1])
    for(i in 2:length(metmethods)){
      strr <- paste(strr, metmethods[i], sep = ", ")
    }
    stop(strr)
  }

  return(.tunezrwhelp4(method, A, Alabels, prior, z_init, tau, sigma2inv_init,thetas_init, nruns_samp, upper = upper, lower = lower, targetrange = targetrange))
}


# helper function inside of tuneiteps2
.tuneepshelp4 <- function(method, A, Alabels, prior, z_init, tau, sigma2inv_init,thetas_init, nruns_samp, upper = 2, lower = 0, targetrange = c(0.8, 0.85)){
  upperver <- F
  while(upperver == F){
    print("tuning step size")
    yy <- .fixedtau_inference_all(A, Alabels, nruns_samp, prior, method, z_init = z_init, tau = tau, sigma2inv_init = sigma2inv_init, eps = upper, L = ceiling(2/upper), thetas_init = thetas_init)
    rat <- mean(yy$z[1,1,-1] != yy$z[1,1,-nruns_samp])
    if(rat > targetrange[2]){
      upper = 2 * upper
    }else{
      if(rat > targetrange[1]){
        return(upper)
      }else{
        upperver <- T
      }
    }
  }
  for(i in 1:100){
    newp <- mean(c(upper, lower))
    print("tuning step size")
    yy <- .fixedtau_inference_all(A, Alabels, nruns_samp, prior, method, z_init = z_init, tau = tau, sigma2inv_init = sigma2inv_init, eps = newp, L = ceiling(2/newp), thetas_init = thetas_init)
    rat <- mean(yy$z[1,1,-1] != yy$z[1,1,-nruns_samp])
    if((rat >= targetrange[1]) && (rat <= targetrange[2])){
      return(newp)
    }
    if(rat < targetrange[1]){
      upper <- newp
    }else{
      if(rat > targetrange[2]){
        lower <- newp
      }
    }
  }
  return(NA)
}


# helper function inside of tuneiteps2
.tunezrwhelp4 <- function(method, A, Alabels, prior, z_init, tau, sigma2inv_init,thetas_init, nruns_samp, upper = 10, lower = 0, targetrange = c(0.2, 0.3)){
  upperver <- F
  while(upperver == F){
    print("tuning step size")
    yy <- .fixedtau_inference_all(A, Alabels, nruns_samp, prior, method, z_init = z_init, tau = tau, sigma2inv_init = sigma2inv_init, zrwsd = upper, thetas_init = thetas_init)
    rat <- mean(yy$z[,,-1] != yy$z[,,-nruns_samp])
    if(rat > targetrange[2]){
      upper = 2 * upper
    }else{
      if(rat > targetrange[1]){
        return(upper)
      }else{
        upperver <- T
      }
    }
  }
  for(i in 1:100){
    newp <- mean(c(upper, lower))
    print("tuning step size")
    yy <- .fixedtau_inference_all(A, Alabels, nruns_samp, prior, method, z_init = z_init, tau = tau, sigma2inv_init = sigma2inv_init, zrwsd = newp, thetas_init = thetas_init)
    rat <- mean(yy$z[,,-1] != yy$z[,,-nruns_samp])
    if((rat >= targetrange[1]) && (rat <= targetrange[2])){
      return(newp)
    }
    if(rat < targetrange[1]){
      upper <- newp
    }else{
      if(rat > targetrange[2]){
        lower <- newp
      }
    }
  }
  return(NA)
}
