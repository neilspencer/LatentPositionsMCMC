.fixedsigma2invtau_inference_all <- function(A, Alabels, nruns, priorprecision = diag(nrow(A)), method = "split HMC + firefly", d = 2, z_init = "MLE", tau, sigma2inv = 1, eps = 1/sqrt(nrow(A)), L = ceiling(2/eps), zrwsd = 0.1 * 1/mean(diag(priorprecision)), tuneparams = FALSE, nruns_samp = 300, thetas_init = NA){
  # initialize by approximate MLE if desired
  if(z_init[1] == "MLE"){
    z_init <- matrix(stats::rnorm(nrow(A) * d), nrow = nrow(A), ncol = d)
    z_init <- MLE_initialize(A, Alabels, priorprecision, z_init, tau, sigma2inv, eps = 0.005, niterations = 300)
  }
  prior <- priorprecision
  # follow the prescribed inference method
  methods <- c("split HMC", "split HMC + firefly", "leapfrog HMC", "leapfrog HMC + firefly", "elliptical slice", "elliptical slice + firefly", "Metropolis within Gibbs", "Metropolis within Gibbs + firefly", "stan", "nuts", "nuts + firefly", "elliptical slice within Gibbs", "elliptical slice within Gibbs + firefly")
  if(!(method %in% methods)){
    strr <- paste("Method must be one of ", methods[1])
    for(i in 2:length(methods)){
      strr <- paste(strr, methods[i], sep = ", ")
    }
    stop(strr)
  }
  runtime_tune <- NA
  params <- list()

  if(sum(is.na(thetas_init)) > 0){
    dyadsmat <- .getdyadsmat(Alabels, A, max(Alabels) + 1)
    dyads = dyadsmat[[1]]
    ndyads = nrow(dyads)
    thetas_init <- rbinom(ndyads, 1, 0.5)
  }

  # split HMC
  if(method == methods[1]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      eps <- .tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
      L <- ceiling(2/eps)
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_splitHMCcholnoFF(A, Alabels, prior, z_init, tau, sigma2inv, nruns, eps, L)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps, L = L)
  }

  # split HMC + FF
  if(method == methods[2]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      eps <- .tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
      L <- ceiling(2/eps)
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_splitHMCchol(A, Alabels, prior, z_init, tau, sigma2inv,thetas_init, nruns, eps, L)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps, L = L)
  }

  # leapfrog HMC
  if(method == methods[3]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      eps <- .tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
      L <- ceiling(2/eps)
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_HMCnoFF(A, Alabels, prior, z_init, tau, sigma2inv, nruns, eps, L)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps, L = L)
  }

  # leapfrog HMC + FF
  if(method == methods[4]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      eps <- .tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
      L <- ceiling(2/eps)
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_HMC(A, Alabels, prior, z_init, tau, sigma2inv,thetas_init, nruns, eps, L)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps, L = L)
  }

  # elliptical slice
  if(method == methods[5]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_slicenoFF(A, Alabels, priorprecision, z_init, tau, sigma2inv, nruns)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list()
  }

  # elliptical slice + FF
  if(method == methods[6]){
    runtime_tune <- 0
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_slice(A, Alabels, priorprecision, z_init, tau, sigma2inv,thetas_init, nruns)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
  }

  # Metropolis within Gibbs
  if(method == methods[7]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      zrwsd <- .tuningfixedsigma2invtauzrw(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = zrwsd, lower = 0, targetrange = c(0.2, 0.3), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_mcmcnoFF(A, Alabels, priorprecision, z_init, tau, sigma2inv, nruns, rwsd = zrwsd)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(zrwsd = zrwsd)
  }

  # Metropolis within Gibbs + FF
  if(method == methods[8]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      zrwsd <- .tuningfixedsigma2invtauzrw(method, A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = zrwsd, lower = 0, targetrange = c(0.2, 0.3), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_mcmc(A, Alabels, priorprecision, z_init,tau, sigma2inv,thetas_init, nruns, rwsd = zrwsd)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(zrwsd = zrwsd)
  }

  # stan
  if(method == methods[9]){
    if(tuneparams == FALSE){
      print("tuneparams = FALSE is not yet available for method = stan. NA returned")
      return(NA)
    }
    fit <- .posterior_inference_stan(A, Alabels, priorprecision, beta1=1, beta2=1, nruns, samplesigma2inv = FALSE, sigma2inv =sigma2inv, sampletau = FALSE, tau = as.array(tau))
    runtime <- fit$runtime
    runtime_tune <- fit$tunetime
    params <- list(eps = fit$epsilon)
  }

  # nuts
  if(method == methods[10]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      #eps <- tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      eps <- .tuningfixedsigma2invtauepsilon(method = methods[1], A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_nutsnoFF(A, Alabels, prior, z_init, tau, sigma2inv, nruns, eps)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps)
  }

  # nuts + FF
  if(method == methods[11]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      #eps <- tuningfixedsigma2invtauepsilon(method, A, Alabels, prior, tau, sigma2inv, z_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      eps <- .tuningfixedsigma2invtauepsilon(method = methods[2], A, Alabels, prior, tau, sigma2inv, z_init,thetas_init, nruns_samp, upper = eps, lower = 0, targetrange = c(0.8, 0.85), d = 2)
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_nuts(A, Alabels, prior, z_init, tau, sigma2inv,thetas_init, nruns, eps)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list(eps = eps)
  }

  # elliptical slice within Gibbs
  if(method == methods[12]){
    if(tuneparams == TRUE){
      time1 <- Sys.time()
      runtime_tune <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    }
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_sliceGibbsnoFF(A, Alabels, prior, z_init, tau, sigma2inv, nruns)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list()
  }

  # elliptical slice within Gibbs + FF
  if(method == methods[13]){
    runetime_tune <- 0
    time1 <- Sys.time()
    fit <- .fixedsigma2invtau_inference_sliceGibbs(A, Alabels, prior, z_init, tau, sigma2inv,thetas_init, nruns)
    runtime <- as.numeric(difftime(Sys.time(), time1, units = "secs"))
    params <- list()
  }
  return(list(z = fit$z, tau = fit$tau, sigma2inv = fit$sigma2inv, logdensity = fit$logdensity, time = runtime, runtime_tune = runtime_tune, params = params, thetas_final = fit$thetas))
}
