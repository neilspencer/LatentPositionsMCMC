#' Constructs objects to facilitate fitting temporal LPM models
#'
#' Uses the MCMC output in \code{"fit"} to obtain a point estimate of the latent positions Z. The point estimate is calculated by computing the posterior expectation of the matrix of squared distances between the latent positions, then using multidimensional scaling to determine the \code{"d"}-dimensional latent positions to best approximate it.
#'
#' @param A_array A three-dimensional array (\code{"nnodes"} by \code{"nnodes"} by \code{"ntimepoints"}) that stores the adjacency matrices
#' @param raw A boolean indicating whether to estimate the raw latent positions or the reparameterized latent positions corresponding to \code{"gamma = 1"}
#' @param d The desired dimension of the latent positions.
#'
#' @return A list containing values
#'
#' A = A, Alabels = Alabels, priorprecision = priorprecision, node_ids = node_ids, timepoints = timepoints
#'
#' @export
prepare_temporal <- function(A_array, Alabels_array, edge_history_covariate = FALSE, rho = 0.95){
  ntimes <- dim(A_array)[3]
  nnodes <- dim(A_array)[2]
  nlabels <- max(c(Alabels_array)) + 1
  if(!all(dim(A_array) == dim(Alabels_array))){
    stop("Dimensions of A_array and Alabels_array do not match")
  }
  A <- matrix(0, nrow = nnodes * ntimes, ncol = nnodes * ntimes)
  Alabels <- A * 0 - 1
  if(edge_history_covariate == FALSE){
    for(i in 1:ntimes){
      A[(i - 1)* nnodes + 1:nnodes, (i - 1)* nnodes + 1:nnodes] <- A_array[,,i]
      Alabels[(i - 1)* nnodes + 1:nnodes, (i - 1)* nnodes + 1:nnodes] <- Alabels_array[,,i]
    }
  }else{
    for(i in 1:ntimes){
      A[(i - 1)* nnodes + 1:nnodes, (i - 1)* nnodes + 1:nnodes] <- A_array[,,i]
      Alabels[(i - 1)* nnodes + 1:nnodes, (i - 1)* nnodes + 1:nnodes] <- Alabels_array[,,i] + Alabels[(i - 1)* nnodes + 1:nnodes, (i - 1)* nnodes + 1:nnodes] * (i > 1)
      if(i < ntimes){
        Alabels[i* nnodes + 1:nnodes, i* nnodes + 1:nnodes] <- nlabels * A_array[,,i] * (Alabels_array[,,i + 1] >= 0)
      }
    }
  }
  diag(Alabels) <- -1
  diag(A) <- 0
  timepoints <- rep(1:ntimes, each = nnodes)
  node_ids <- as.factor(rep(1:nnodes, ntimes))
  priorprecision <- priorMatrix_temporal(nnodes, ntimes, rho)
  to_remove <- c()
  for(i in 1:nrow(Alabels)){
    if(max(Alabels[i,]) < 0){
      to_remove <- c(to_remove, i)
    }
  }
  if(!is.null(to_remove)){
    timepoints <- timepoints[-to_remove]
    node_ids <- node_ids[-to_remove]
    Alabels <- Alabels[-to_remove, -to_remove]
    A <- A[-to_remove, -to_remove]
    priorprecision <- priorprecision[-to_remove, -to_remove]
  }



  return(list(A = A, Alabels = Alabels, priorprecision = priorprecision, node_ids = node_ids, timepoints = timepoints))
}

posterior_inference_LPM_temporal <- function(A_array, Alabels_array, nruns, rho = 0.95, edge_history_covariate = FALSE, d = 2, method = "split HMC + firefly", sample_tau = TRUE, sample_gamma2 = TRUE, z_init = "MLE", tau_init = rep(0.5, (1 + edge_history_covariate) * (1 + max(Alabels_array))), gamma2_init = 1, alpha_param = rep(1, length(tau_init)), beta_param = rep(1, length(tau_init)), a_param = 1, b_param = 1, eps = 1/sqrt(nrow(A)), L = ceiling(2/eps), taurwsd = 0.05, zrwsd = 0.1 * 1/mean(diag(priorprecision)), tuneparams = TRUE, nruns_tuning = 300, thetas_init = NA){
  Alabels_array[which(is.na(Alabels_array))] <- -1
  components <- prepare_temporal(A_array, Alabels_array, edge_history_covariate, rho)
  A <- components$A
  Alabels <- components$Alabels
  priorprecision <- components$priorprecision
  fit <- posterior_inference_LPM(A, Alabels, nruns, priorprecision, d, method = method, sample_tau, sample_gamma2, z_init, tau_init, gamma2_init, alpha_param, beta_param, a_param, b_param, eps, L, taurwsd, zrwsd, tuneparams, nruns_tuning, thetas_init)
  fit$timepoints <- components$timepoints
  fit$node_ids <- components$node_ids
  return(fit)
}
