# for getting the trace of the posterior probability for a set of edges
.fit_trace <- function(fit, missingdyads = cbind(c(1,2,3,4), c(2,3,4,1), c(fit$Alabels[1, 2], fit$Alabels[2, 3], fit$Alabels[3, 4], fit$Alabels[4, 1]))){
  dists <- t(.getdistances(missingdyads[,1], missingdyads[,2], fit$z, dim(fit$z)[3], nrow(missingdyads), d = 2))
  logprobs <- -dists/2
  for(j in 1:nrow(missingdyads)){
    logprobs[,j] <- logprobs[,j]  + log(fit$tau[missingdyads[j,3] + 1,])
  }
  gamma2 <- fit$gamma2
  taus <- fit$tau
  df <- data.frame(iteration = 1:length(gamma2), gamma2 = gamma2)
  for(i in 1:nrow(taus)){
    stringname <-  paste("tau", i, sep = "")
    df <- cbind(df, taus[i,])
    names(df)[length(names(df))] <- stringname
  }
  for(i in 1:nrow(missingdyads)){
    stringname <-  paste("logprob", i, sep = "")
    df <- cbind(df, logprobs[,i])
    names(df)[length(names(df))] <- stringname
  }
  return(df)
}

trace_plots <- function(fit, missingdyads = cbind(c(1,2,3,4), c(2,3,4,1), c(fit$Alabels[1, 2], fit$Alabels[2, 3], fit$Alabels[3, 4], fit$Alabels[4, 1]))){
  dat <- .fit_trace(fit, missingdyads)
  dat_tau <- reshape::melt(dat, id.vars=names(dat)[!(substr(names(dat), 1,1) == "t")])
  dat_logprob <- reshape::melt(dat, id.vars=names(dat)[!(substr(names(dat), 1,1) == "l")])
  levels(dat_logprob$variable) <- paste("A_{", missingdyads[,1], ",", missingdyads[,2], "}", sep = "")
  plotslist <- list()
  pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$gamma2, x = .data$iteration)) + ggplot2::geom_line() + ggplot2::theme_bw() + ggplot2::ylab("gamma2") + ggplot2::xlab("MCMC iteration")
  plotslist[[1]] <- pp
  pp <- ggplot2::ggplot(dat_tau, ggplot2::aes(y = .data$value, x = .data$iteration, color = .data$variable)) + ggplot2::geom_line() + ggplot2::theme_bw() + ggplot2::ylab("tau value") +ggplot2::xlab("MCMC iteration") + ggplot2::labs(color = "tau index")
  plotslist[[2]] <- pp
  pp <- ggplot2::ggplot(dat_logprob, ggplot2::aes(y = .data$value, x = .data$iteration, color = .data$variable)) + ggplot2::geom_line() + ggplot2::theme_bw() + ggplot2::ylab("log probability of edge") +ggplot2::xlab("MCMC iteration") + ggplot2::labs(color = "edge") + ggplot2::facet_wrap(~.data$variable)
  plotslist[[3]] <- pp
  df <- data.frame(iteration = 1:length(fit$logdensity), logpost = fit$logdensity )
  pp <- ggplot2::ggplot(df, ggplot2::aes(y = .data$logpost, x = .data$iteration)) + ggplot2::geom_line() + ggplot2::theme_bw() + ggplot2::ylab("log posterior density") + ggplot2::xlab("MCMC iteration (thinned by 100)")
  plotslist[[4]] <- pp
  return(plotslist)
}

# finds the quantiles of ESS for all edge dyads in the network, as well as all ESSs
ess_dyads <- function(fit, missingdyads = cbind(c(1,2,3,4), c(2,3,4,1), c(fit$Alabels[1, 2], fit$Alabels[2, 3], fit$Alabels[3, 4], fit$Alabels[4, 1])), burnin = 10, quantiles = c(0, 0.25, 0.5, 0.75, 1.0)){
  ntaus <- length(fit$tau_init)

  dat <- data.frame(nnodes = NA)
  for(i in 1:ntaus){
    stringname <-  paste("tau", i, "mean", sep = "")
    dat <- cbind(dat, NA)
    names(dat)[length(names(dat))] <- stringname
  }
  dat <- cbind(dat, data.frame(gamma2mean = NA, method = NA, time = NA, time_tune = NA, stepsize = NA, acceptrate= NA))


  dat <- cbind(dat, matrix(NA, nrow = 1, ncol = length(quantiles)))
  names(dat)[7 + ntaus + (1:length(quantiles))] <- paste("esslogprobquantile", quantiles, sep = "")
  allesss <- list()
  A <- fit$A
  Alabels <- fit$Alabels
  dat$nnodes[1] <- nrow(A)
  dat[,1 + (1:ntaus)] <- c(rowMeans(fit$tau))
  dat$gamma2mean[1] <- mean(fit$gamma2)
  dat$method[1] = as.character(fit$method)
  dat$time[1] <- fit$time
  dat$time_tune[1] <- fit$runtime_tune
  if(is.na(fit$params[1])){
    dat$stepsize[1] <- NA
  }else if(!is.null((fit$params)$eps)){
    dat$stepsize[1] <- (fit$params)$eps
  }else if(!is.null((fit$params)$zrwsd)){
    dat$stepsize[1] <- (fit$params)$zrwsd
  }else{
    dat$stepsize[1] <- NA
  }
  dat$acceptrate[1] <- mean(fit$z[1,1,-1] != fit$z[1,1,-length(fit$z[1,1,])])
  xxx <- .fit_trace(fit, missingdyads)
  eff <- coda::effectiveSize(xxx[, (3 + length(fit$tau_init)):ncol(xxx)])
  allesss[[1]] <- cbind(missingdyads, eff)
  dat[1, 7 + ntaus + (1:length(quantiles))] <- quantile(eff, quantiles)
  toreturn = list(summary = dat, allesss = allesss)
  names(toreturn) <- c("summary", "alledges")
  return(toreturn)
}

# finds the quantiles of ESS for all edge dyads in the network, as well as all ESSs
ess_edges <- function(fit, burnin = 10, quantiles = c(0, 0.25, 0.5, 0.75, 1.0)){
  A <- fit$A
  Alabels <- fit$Alabels
  a1 <- c(A * matrix(1:nrow(A), nrow(A), ncol(A)))
  a2 <- c(A * t(matrix(1:nrow(A), nrow(A), ncol(A))))
  a3 <- c(Alabels)
  missingdyads <- cbind(a1[a1!=0], a2[a2!=0], a3[a2!=0])
  missingdyads <- missingdyads[missingdyads[,1] <= missingdyads[,2],]
  return(ess_dyads(fit, missingdyads, burnin = 10, quantiles = c(0, 0.25, 0.5, 0.75, 1.0)))
}

# # for a list of fits created by different algorithms,
# # and a set of 4 missingdyads (those after 4 discarded),
# # plots diagnostics for the sampling of various parameters
# # Note---not made public for final package because it is really only useful for
# # testing
# .compare_mixing <- function(fits, missingdyads = cbind(c(1,2,3,4), c(2,3,4,1), c(fits[[1]]$Alabels[1, 2], fits[[1]]$Alabels[2, 3], fits[[1]]$Alabels[3, 4], fits[[1]]$Alabels[4, 1]))){
#   dat <- cbind(fit_trace(fits[[1]], missingdyads[1:4,]), method = fits[[1]]$method)
#   if(length(fits) > 1){
#     for(i in 2:length(fits)){
#       dat <- rbind(dat, cbind( fit_trace(fits[[i]], missingdyads[1:4,]), method = fits[[i]]$method))
#     }
#   }
#   plotslist <- list()
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$gamma2, x = .data$method)) + ggplot2::geom_line() + ggplot2::theme_bw()
#   plotslist[[1]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$gamma2, x = .data$method)) + ggplot2::geom_line() + ggplot2::theme_bw()
#   plotslist[[1]] <- pp
#
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$logprob1, x = .data$method)) + ggplot2::geom_boxplot() + ggplot2::coord_flip()
#   plotslist[[1]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$logprob2, x = .data$method)) + ggplot2::geom_boxplot() + ggplot2::coord_flip()
#   plotslist[[2]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$logprob3, x = .data$method)) + ggplot2::geom_boxplot() + ggplot2::coord_flip()
#   plotslist[[3]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$logprob4, x = .data$method)) + ggplot2::geom_boxplot() + ggplot2::coord_flip()
#   plotslist[[4]] <- pp
#
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = .data$gamma2, x = .data$method)) + ggplot2::geom_boxplot() + ggplot2::coord_flip()
#   plotslist[[6]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = rank(.data$logprob1), x= .data$iteration)) + ggplot2::geom_line() + ggplot2::facet_wrap(~.data$method)
#   plotslist[[7]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = rank(.data$gamma2), x= .data$iteration)) + ggplot2::geom_line() + ggplot2::facet_wrap(~.data$method)
#   plotslist[[8]] <- pp
#   pp <- ggplot2::ggplot(dat, ggplot2::aes(y = rank(.data$tau1), x= .data$iteration)) + ggplot2::geom_line() + ggplot2::facet_wrap(~.data$method)
#   plotslist[[9]] <- pp
#   return(plotslist)
# }


#
# # finds the quantiles of ESS for a specified set of dyads, as well as all ESSs
# .process_fitlist_esssummary <- function(fits, missingdyads, burnin = 10, quantiles = c(0,0.25, 0.5, 0.75, 1.0)){
#   nfits <- length(fits)
#   ntaus <- length(fits[[1]]$tau_init)
#
#   dat <- data.frame(nnodes = rep(NA, nfits))
#   for(i in 1:ntaus){
#     stringname <-  paste("tau", i, sep = "")
#     dat <- cbind(dat, NA)
#     names(dat)[length(names(dat))] <- stringname
#   }
#   dat <- cbind(dat, data.frame(gamma2 = rep(NA, nfits), sample_tau = rep(NA, nfits), sample_gamma2 = rep(NA, nfits), method = rep(NA, nfits), time = rep(NA, nfits), time_tune = rep(NA, nfits), eps = rep(NA, nfits), acceptrate= rep(NA, nfits)))
#
#
#   dat <- cbind(dat, matrix(NA, nrow = nfits, ncol = length(quantiles)))
#   names(dat)[9 + ntaus + (1:length(quantiles))] <- paste("esslogprobquantile", quantiles, sep = "")
#   allesss <- list()
#   for(i in (1:nfits)){
#     print(paste("fit", i))
#     #add all dyads corresponding to an edge
#     A <- fits[[i]]$A
#     Alabels <- fits[[i]]$Alabels
#     dat$nnodes[i] <- nrow(A)
#     dat[,1 + (1:ntaus)] <- rep(fits[[i]]$tau_init, each = nrow(dat))
#     dat$gamma2 <- fits[[i]]$gamma2
#     dat$sample_tau <- fits[[i]]$sample_tau
#     dat$sample_gamma2 <- fits[[i]]$sample_gamma2
#     dat$method[i] = as.character(fits[[i]]$method)
#     dat$time[i] <- fits[[i]]$time
#     dat$time_tune[i] <- fits[[i]]$runtime_tune
#     if(is.na(fits[[i]]$params[1])){
#       dat$eps[i] <- NA
#     }else if(is.null((fits[[i]]$params)$eps)){
#       dat$eps[i] <- NA
#     }else{
#       dat$eps[i] <- (fits[[i]]$params)$eps
#     }
#     dat$acceptrate[i] <- mean(fits[[i]]$z[1,1,-1] != fits[[i]]$z[1,1,-length(fits[[i]]$z[1,1,])])
#     xxx <- fit_trace(fits[[i]], missingdyads)
#     eff <- coda::effectiveSize(xxx[, (3 + length(fits[[i]]$tau_init)):ncol(xxx)])
#     allesss[[i]] <- cbind(missingdyads, eff)
#     dat[i, 9 + ntaus + (1:length(quantiles))] <- quantile(eff, quantiles)
#   }
#   toreturn = list(summary = dat, allesss = allesss)
#   names(toreturn) <- c("summary", "alledges")
#   return(toreturn)
# }
#
# # finds the quantiles of ESS for all edge dyads in the network, as well as all ESSs
# .process_fitlist_essedges <- function(fits, burnin = 10, quantiles = c(0,0.25, 0.5, 0.75, 1.0)){
#   nfits <- length(fits)
#   ntaus <- length(fits[[1]]$tau_init)
#
#   dat <- data.frame(nnodes = rep(NA, nfits))
#   for(i in 1:ntaus){
#     stringname <-  paste("tau", i, sep = "")
#     dat <- cbind(dat, NA)
#     names(dat)[length(names(dat))] <- stringname
#   }
#   dat <- cbind(dat, data.frame(sigma2inv = rep(NA, nfits), sample_tau = rep(NA, nfits), sample_sigma2inv = rep(NA, nfits), method = rep(NA, nfits), time = rep(NA, nfits), time_tune = rep(NA, nfits), eps = rep(NA, nfits), acceptrate= rep(NA, nfits)))
#
#
#   dat <- cbind(dat, matrix(NA, nrow = nfits, ncol = length(quantiles)))
#   names(dat)[9 + ntaus + (1:length(quantiles))] <- paste("esslogprobquantile", quantiles, sep = "")
#   allesss <- list()
#   for(i in (1:nfits)){
#     #add all dyads corresponding to an edge
#     print(paste("fit", i))
#     A <- fits[[i]]$A
#     Alabels <- fits[[i]]$Alabels
#     dat$nnodes[i] <- nrow(A)
#     dat[,1 + (1:ntaus)] <- rep(fits[[i]]$tau_init, each = nrow(dat))
#     dat$gamma2 <- fits[[i]]$gamma2_init
#     dat$sample_tau <- fits[[i]]$sample_tau
#     dat$sample_gamma2 <- fits[[i]]$sample_gamma2
#     a1 <- c(A * matrix(1:nrow(A), nrow(A), ncol(A)))
#     a2 <- c(A * t(matrix(1:nrow(A), nrow(A), ncol(A))))
#     a3 <- c(Alabels)
#     missingdyads <- cbind(a1[a1!=0], a2[a2!=0], a3[a2!=0])
#     missingdyads <- missingdyads[missingdyads[,1] <= missingdyads[,2],]
#     dat$method[i] = as.character(fits[[i]]$method)
#     dat$time[i] <- fits[[i]]$time
#     dat$time_tune[i] <- fits[[i]]$runtime_tune
#     if(is.na(fits[[i]]$params[1])){
#       dat$eps[i] <- NA
#     }else if(is.null((fits[[i]]$params)$eps)){
#       dat$eps[i] <- NA
#     }else{
#       dat$eps[i] <- (fits[[i]]$params)$eps
#     }
#     dat$acceptrate[i] <- mean(fits[[i]]$z[1,1,-1] != fits[[i]]$z[1,1,-length(fits[[i]]$z[1,1,])])
#     xxx <- fit_trace(fits[[i]], missingdyads)
#     eff <- coda::effectiveSize(xxx[, (3 + length(fits[[i]]$tau_init)):ncol(xxx)])
#     allesss[[i]] <- cbind(missingdyads, eff)
#     dat[i, 9 + ntaus + (1:length(quantiles))] <- quantile(eff, quantiles)
#   }
#   toreturn = list(summary = dat, allesss = allesss)
#   names(toreturn) <- c("summary", "alledges")
#   return(toreturn)
# }


# .getRelativePerformance <- function(results){
#   newten <- which(names(results) == "acceptrate")
#   themetric <- matrix(NA, nrow = nrow(results), ncol = ncol(results) - newten)
#   subb <- subset(results, .data$method == "Metropolis within Gibbs")
#   for(i in 1:nrow(results)){
#     notfound <- TRUE
#     j <- 1
#     while(notfound){
#       if(prod(results[i,1:(newten - 5)] == subb[j,1:(newten - 5)] ) == 1){
#         notfound <- FALSE
#         indy <-subb[j,]
#       }else{
#         j <- j + 1
#       }
#     }
#     themetric[i,] <- as.matrix((results[i,(newten + 1):ncol(results)]/results$time[i])/(indy[,(newten + 1):ncol(results)]/indy$time))[1,]
#   }
#   dfnew <- cbind(results, themetric)
#   names(dfnew)[ncol(results) + 1:(ncol(results) - newten)] <- paste(names(results)[(newten + 1):ncol(results)], "comparison", sep = "")
#   return(dfnew)
# }

# #compares the per dyad performance of all methods (all dyads must be the same)
# .dyadComparison <- function(results){
#   newten <- which(names(results[[1]]) == "acceptrate")
#   fulldf <- cbind(results[[1]][,1:newten], matrix(NA, nrow = nrow(results[[1]]), ncol = nrow(results[[2]][[2]])))
#   for(i in 1:nrow(fulldf)){
#     fulldf[i, (newten + 1):ncol(fulldf)] <- c(results[[2]][[i]][,4] )
#   }
#   performance <- getRelativePerformance(fulldf)
#   forplotting <- reshape::melt(performance, 1:newten, (ncol(fulldf) + 1):ncol(performance))
#   node1 <- results[[2]][[1]][as.numeric(gsub("c.*","",as.character(forplotting[,newten + 1]))), 1]
#   node2 <- results[[2]][[1]][as.numeric(gsub("c.*","",as.character(forplotting[,newten + 1]))), 2]
#   nodelabel <- results[[2]][[1]][as.numeric(gsub("c.*","",as.character(forplotting[,newten + 1]))), 3]
#   forplotting <- cbind(forplotting[,1:newten], node1 = node1, node2 = node2, nodelabel = nodelabel, relativeESSperSecond = forplotting[,newten + 2])
#   return(forplotting)
# }
