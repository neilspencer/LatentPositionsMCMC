
#' Runs MCMC for Bayesian inference of a Gaussian Latent Position Network Model
#'
#' Runs Markov chain Monte Carlo to sample from the posterior of the latent positions and link function parameters for a Gaussian Latent Position Model fit to a n by n adjacency matrix \code{A} (representing undirected binary relationships between n nodes). Any categorical covariates or unobserved dyads are encoded using the n by n matrix \code{Alabels}.
#'
#' @param A An \code{n} by \code{n} binary adjacency matrix. Entries taking the value of 1 indicate an observed edge between the corresponding dyad.
#' @param Alabels An \code{n} by \code{n} matrix taking on the values of -1,0,1,..,C-1 for any positive integer C. For observed dyads, the values 0,1,...,C-1 are used to encode which of C possible values of a categorical covariate are observed for the dyad. Here, C=1 would mean no observed covariates. Unobserved dyads are encoded with entries taking the value -1.
#' @param nruns The number of MCMC iterations for which to run the algorithm
#' @param priorprecision The \code{n} by \code{n} precision matrix of the zero mean Gaussian prior on the latent positions for each dimension of the latent space.
#' @param d The dimension of the latent space
#' @param method The MCMC algorithm to use to generate the chain. Must be one of \code{split HMC}, \code{split HMC + firefly}, \code{leapfrog HMC}, \code{leapfrog HMC + firefly}, \code{elliptical slice}, \code{elliptical slice + firefly}, \code{Metropolis within Gibbs}, \code{Metropolis within Gibbs + firefly}, \code{stan}, \code{nuts}, \code{nuts + firefly}, \code{elliptical slice within Gibbs}, or \code{elliptical slice within Gibbs + firefly}.
#' @param sample_tau An indicator of whether or not the parameter tau of the link function should be sampled in the MCMC algorithm, or held fixed at their initialized value
#' @param sample_gamma2 An indicator of whether or not the parameter gamma2 of the link function should be sampled in the MCMC algorithm, or held fixed at at their initialized value
#' @param z_init A \code{n} by \code{d} matrix to initialize the latent positions in the chain. If the string MLE is provided, the chain will be initialized at a local maximum of the log posterior.
#' @param tau_init A vector of length \code{C} taking on values in the unit interval to initialize the value of tau in the chain
#' @param gamma2_init The positive real value with which to initialize gamma2 in the chain
#' @param alpha_param A vector of length \code{C} prescribing the alpha parameters for the prior on tau
#' @param beta_param A vector of length \code{C} prescribing the beta parameters for the prior on tau
#' @param a_param A positive real value prescribing the a parameter for the inverse gamma prior on gamma2
#' @param b_param A positive real value prescribing the b parameter for the inverse gamma prior on gamma2
#' @param eps The value of step size epsilon to use to integrate the Hamiltonian. This argument is only used if a Hamiltonian Monte Carlo-based algorithm is used to update the latent positions. This plays the role of the initial value considered if \code{tuneparams = TRUE}
#' @param L The integer value of number of steps used to integrate the motion. This argument is only used if a Hamiltonian Monte Carlo-based algorithm is used to update the latent positions.
#' @param taurwsd The step size for the random walk Metropolis updates on each entry in tau. This argument is not used if a firefly based method is used. It serves as the initial value considered if \code{tuneparams = TRUE}
#' @param zrwsd The step size for the random walk Metropolis updates on each latent position if a Metropolis-within-Gibbs method is used. It serves as the initial value considered if \code{tuneparams = TRUE}
#' @param tuneparams An indicator of whether or not to use prelminary tuning runs to choose the sampler parameters \code{eps}, \code{L}, \code{taurwsd}, \code{zrsd} for the MCMC method, or to keep them fixed at their initial values. \code{tuneparams = FALSE} not available for stan.
#' @param nruns_tuning The number of iterations for each preliminary tuning run if \code{tuneparams = TRUE}. Multiple preliminary tuning runs will be made until reasonable acceptance rates are obtained. We strongly recommend that this value be no less than 50 to ensure stability.
#' @param thetas_init Initialization of the theta variables if any firefly-based method is used. If NA is provided, initial values will be generated before running.
#'
#'@details The outputted list contains:
#' \itemize{
#'   \item \code{z}: an \code{n} by \code{d} by \code{nruns} array representing each MCMC draw of the latent positions, re-parametrized such that \code{gamma2 = 1}.
#'   \item \code{zraw}: an \code{n} by \code{d} by \code{nruns} array representing each MCMC draw of the latent positions. This is the raw, not re-parametrized, representation.
#'   \item \code{tau}: an \code{C} by \code{nruns} matrix representing each MCMC draw of tau
#'   \item \code{gamma2}: an vector containing the \code{nruns} MCMC draw of \code{gamma2}
#'   \item \code{logdensity}: A vector tracking the log of the posterior up to an additive constant once every 100 draws
#'   \item \code{time}: The wall time in seconds of the chain's run after tuning.
#'   \item \code{runtime_tune}: The wall time in seconds of the tuning stage.
#'   \item \code{params}: A list containing the relevant parameters used for the algorithm  such as \code{eps}, \code{L}, \code{taurwsd}, \code{zrsd}.
#'   \item \code{thetas_final}: If a firefly algorithm was used, this holds the value of the theta parameters at the final iteration. This is useful if one wants to start another chain where this one left off.
#'   \item \code{A}, \code{Alabels}, \code{sample_tau}, \code{sample_gamma2}, \code{tau_init}, \code{gamma2_init} : contain the corresponding inputs used to run the chain.
#'   \item \code{priors}: A list containing the values of \code{priorprecision}, \code{alpha_param}, \code{beta_param}, \code{a_param}, \code{b_param}.
#' }
#' @return A list containing the output of the algorithm, as well as the parameters used to run it. See details for more.
#'
#'
#' @export
posterior_inference_LPM <- function(A, Alabels, nruns, priorprecision = diag(nrow(A)), d = 2, method = "split HMC + firefly", sample_tau = TRUE, sample_gamma2 = TRUE, z_init = "MLE", tau_init = rep(0.5, 1 + max(Alabels)), gamma2_init = 1, alpha_param = rep(1, 1 + max(Alabels)), beta_param = rep(1, 1 + max(Alabels)), a_param = 1, b_param = 1, eps = 1/sqrt(nrow(A)), L = ceiling(2/eps), taurwsd = 0.05, zrwsd = 0.1 * 1/mean(diag(priorprecision)), tuneparams = TRUE, nruns_tuning = 300, thetas_init = NA){

  Alabels[which(is.na(Alabels))] <- -1
  if(method == "stan"){
    print("If an error returned while using method=stan, try loading the rstan library with library(rstan).")
    #return(NA)
  }
  # The following is just a re-naming so that the user accessed function
  # reflects the notation I used in the paper.
  sigma2inv_init = gamma2_init
  sample_sigma2inv = sample_gamma2
  beta1 = alpha_param
  beta2 = beta_param
  sigparam1 = a_param
  sigparam2 = b_param

  if((sample_tau == TRUE) & (sample_sigma2inv == TRUE)){
    fit <- .posterior_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, beta1 = beta1, beta2 = beta2, sigparam1 = sigparam1, sigparam2 = sigparam2, d = d, z_init = z_init, tau_init = tau_init, sigma2inv_init = sigma2inv_init, eps = eps, L = L, taurwsd = taurwsd, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
  }
  if((sample_tau == FALSE) & (sample_sigma2inv == TRUE)){
    fit <- .fixedtau_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, sigparam1 = sigparam1, sigparam2 = sigparam2, d = d, z_init = z_init, tau = tau_init, sigma2inv_init = sigma2inv_init, eps = eps, L = L, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    names(fit)[2] <- "gamma2" # another change just to fit the new notation
    fit$tau <- matrix(tau_init, nrow = length(tau_init), ncol = nruns)
  }
  if((sample_tau == FALSE) & (sample_sigma2inv == FALSE)){
    fit <- .fixedsigma2invtau_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, d = d, z_init = z_init, tau = tau_init, sigma2inv = sigma2inv_init, eps = eps, L = L, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    fit$sigma2inv <- rep(sigma2inv_init, nruns)
    fit$tau <- matrix(tau_init, nrow = length(tau_init), ncol = nruns)
  }
  if((sample_tau == TRUE) & (sample_sigma2inv == FALSE)){
    fit <- .fixedsigma2inv_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, beta1 = beta1, beta2 = beta2, d = d, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, eps = eps, L = L, taurwsd = taurwsd, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    fit$sigma2inv <- rep(sigma2inv_init, nruns)
  }
  names(fit)[names(fit) == "sigma2inv"] <- "gamma2" # another change just to fit the new notation
  fit$method <- method
  fit$A <- A
  fit$Alabels <- Alabels
  fit$sample_tau <- sample_tau
  fit$sample_gamma2 <- sample_gamma2
  fit$tau_init <- tau_init
  fit$gamma2_init <- gamma2_init
  # reconstruct the values of z before the reparametrization
  fit$zraw <- aperm(apply(fit$z, c(1,2), function(x) x * sqrt(fit$gamma2)), c(2,3,1))
  fit$priors <- list(priorprecision = priorprecision, alpha_param = alpha_param, beta_param = beta_param, a_param = a_param, b_param = b_param)
  return(fit)
}

posterior_inference_LPM_continuation <- function(fit, nruns, combine = TRUE){
  method <- fit$method
  if(method == "stan"){
    print("posterior_inference_LPM_continuation is not yet available for method = stan. NA returned")
    return(NA)
  }
  nprev <- dim(fit$z)[3]
  A <- fit$A
  Alabels <- fit$Alabels
  priorprecision <- (fit$priors)$priorprecision
  alpha_param <- (fit$priors)$alpha_param
  beta_param <- (fit$priors)$beta_param
  a_param <- (fit$priors)$a_param
  b_param <- (fit$priors)$b_param
  d <- dim(fit$z)[2]
  sample_tau <- fit$sample_tau
  sample_gamma2 <- fit$sample_gamma2
  z_init <- fit$z[, , nprev]
  tau_init <- fit$tau_init
  if(sample_tau){
    tau_init <- fit$tau[, nprev]
  }
  gamma2_init <- fit$gamma2_init
  if(sample_gamma2){
    gamma2_init <- fit$gamma2[nprev]
  }
  taurwsd <- (fit$params)$taurwsd
  eps <- (fit$params)$eps
  zrwsd <- (fit$params)$zrwsd
  L <- (fit$params)$L
  thetas_init <- fit$thetas_final
  fitnew <- posterior_inference_LPM(A, Alabels, nruns, priorprecision = priorprecision, d = d, method = method, sample_tau = sample_tau, sample_gamma2 = sample_gamma2, z_init = z_init, tau_init = tau_init, gamma2_init = gamma2_init, alpha_param = alpha_param, beta_param = beta_param, a_param = a_param, b_param = b_param, eps = eps, L = L, taurwsd = taurwsd, zrwsd = zrwsd, tuneparams = FALSE, thetas_init = NA)
  if(combine == FALSE){
    return(fitnew)
  }
  else{
    tau <- cbind(fit$tau, fitnew$tau)
    gamma2 <- c(fit$gamma2, fitnew$gamma2)
    logdensity <- c(fit$logdensity, fitnew$logdensity)
    dimzall <- dim(fit$z)
    dimzall[3] <- dimzall[3] + nruns
    zall <- array(dim = dimzall)
    zrawall <- array(dim = dimzall)
    zall[, , 1:(dimzall[3] - nruns)] <- fit$z
    zall[, , (dimzall[3] - nruns) + 1:nruns] <- fitnew$z
    zrawall[, , 1:(dimzall[3] - nruns)] <- fit$zraw
    zrawall[, , (dimzall[3] - nruns) + 1:nruns] <- fitnew$zraw
    fitnew$z <- zall
    fitnew$zraw <- zrawall
    fitnew$tau <- tau
    fitnew$gamma2 <- gamma2
    fitnew$logdensity <- logdensity
    fitnew$time <- fitnew$time + fit$time
    fitnew$runtime_tune <- fit$runtime_tune
    return(fitnew)
  }
}

# #designs an experiment where it generates a synthetic network then runs the desired mcmc method on it. graphseed generates the graph and mcmc seed generates the chain
# experimental_run_LPM <- function(Alabels, tau, gamma2, priorprecision, method, nruns, sample_tau, sample_gamma2, graphseed = 1, mcmcseed = 1, nruns_tuning = 300, eps = 1/sqrt(nrow(Alabels)), L = ceiling(2/eps), taurwsd = 0.05, zrwsd =  0.1/mean(diag(priorprecision))){
#   set.seed(graphseed)
#   creation <- createA(Alabels, tau, priorprecision, gamma2, d = 2)
#   A <- creation$A
#   set.seed(mcmcseed)
#   fit <- posterior_inference(A, Alabels, nruns, priorprecision = priorprecision, method = method, sample_tau = sample_tau, sample_gamma2 = sample_gamma2, nruns_tuning = nruns_tuning, eps = eps, taurwsd = taurwsd, zrwsd = zrwsd, tau_init = tau, gamma2_init = gamma2)
#   return(fit)
# }



