.procrust <- function(Z, X){
  Z <- t(t(Z) - colMeans(Z))
  X <- t(t(X) - colMeans(X))
  mid <- t(Z) %*% X %*% t(X) %*% Z
  eig <- eigen(mid)
  mid2 <- eig$vectors %*% diag(1/sqrt(eig$values)) %*% t(eig$vectors )
  return(t(t(X) %*% Z %*% mid2 %*% t(Z)))
}


plotNetwork <- function(A, z = cbind(cos(2 * pi * (1:nrow(A))/nrow(A)), sin(2 * pi * (1:nrow(A))/nrow(A))), node_ids = as.factor(1:nrow(z)), node_color = c("#00C7FC"), node_size = 3, nodes_colored_by_id = F, node_palette = NA, show_edges = TRUE, edge_color = "black", edge_size = 0.5, edge_curve = 0, show_axes = T, legend_title = NA, use_shapes = FALSE){

  ztrue <- z
  dfnodes <- data.frame(x = ztrue[,1], y = ztrue[,2], node_ids = node_ids)

  p <- ggplot2::ggplot(dfnodes, ggplot2::aes(x = .data$x, y = .data$y))
  if(show_edges == TRUE){
    empt <- rep(NA, sum(A))
    dfedges <- data.frame(xstart = empt, xend = empt, ystart = empt, yend = empt)
    edgelist <- data.frame(v1 = c(), v2 = c())
    for(i in 1:nrow(A)){
      edges <- (1:nrow(A))[A[i,] == 1]
      if(length(edges) > 0){
        nex <- cbind(v1 = i, v2 = edges)
        edgelist <- rbind(edgelist, nex)
      }
    }
    for(i in 1:length(empt)){
      dfedges[i,] <- c(ztrue[edgelist[i,1], 1], ztrue[edgelist[i,2], 1], ztrue[edgelist[i,1], 2], ztrue[edgelist[i,2], 2])
    }
    dfedges <- dfedges[dfedges$yend > dfedges$ystart,]
    p <- p + ggplot2::geom_curve(data = dfedges, ggplot2::aes(x = .data$xstart, y = .data$ystart, xend = .data$xend, yend = .data$yend), curvature = edge_curve, color = edge_color, size = edge_size)
  }
  if(nodes_colored_by_id == FALSE){
    p <- p +  ggplot2::geom_point(shape = 21, colour = "black", fill = node_color, size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
  }else{
    if(is.factor(node_ids)){
      if(length(node_palette) != length(unique(node_ids))){
        if(!is.na(node_palette[1])){
          print("Incorrect length node_palette supplied. Using default.")
          node_palette <- NA
        }
      }
      if(is.na(node_palette[1])){
        if(length(unique(node_ids)) <= 2){
          aaa <- c("#00C7FC", "red")
        }else if(length(unique(node_ids)) <= 11){
          aaa <- RColorBrewer::brewer.pal(length(unique(node_ids)),"Spectral")
        }else{
          colfunc <- colorRampPalette(c("red","yellow","springgreen","royalblue"))
          aaa <- colfunc(length(unique(node_ids)))
        }
      }else{
        aaa <- node_palette
      }
      names(aaa) <- as.factor(unique(node_ids))
      if(use_shapes){
        nodelen <- length(unique(node_ids))
        bbb <- rep(21:25, length.out = nodelen)
        names(bbb) <- names(aaa)
        p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids, shape = .data$node_ids), colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
        p <- p +  ggplot2::scale_fill_manual(name = legend_title, values= aaa) + ggplot2::scale_shape_manual(name = legend_title, values = bbb)
      }
      else{
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p +  ggplot2::scale_fill_manual(values= aaa)
      }
    }else{
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p + ggplot2::scale_fill_distiller(palette = "Spectral")
    }
  }
  if(show_axes == F){
    p <- p + ggplot2::theme(axis.line= ggplot2::element_blank(), axis.text.x= ggplot2::element_blank(),
                   axis.text.y=ggplot2::element_blank(),axis.ticks=ggplot2::element_blank(),
                   axis.title.x=ggplot2::element_blank(),
                   axis.title.y=ggplot2::element_blank(),
                   panel.background=ggplot2::element_blank(),panel.border=ggplot2::element_blank(),panel.grid.major=ggplot2::element_blank(),
                   panel.grid.minor=ggplot2::element_blank(),plot.background=ggplot2::element_blank())
    if(is.na(legend_title) == T){
      p <- p + ggplot2::theme(legend.position="none")
    }

  }else{
    p <- p + ggplot2::theme_bw() + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank()) + ggplot2::xlab("Z1") + ggplot2::ylab("Z2")
    if(is.na(legend_title) == T){
      p <- p + ggplot2::theme(legend.position="none")
    }else{
      p <- p + ggplot2::labs(fill = legend_title)
    }
  }
  extreme <- 4/3 * max(abs(z))
  p <- p + ggplot2::xlim(c(-extreme, extreme)) + ggplot2::ylim(c(-extreme, extreme))
  return(p)
}


plotNetworkFit <- function(fit, node_subset = 1:nrow(fit$A), uncertainty_subset = c(), node_ids = as.factor(1:nrow(fit$A)), nodes_colored_by_id = F, node_size = 3, node_palette = NA, show_edges = T, edge_color = "black", edge_size = 0.5, edge_curve = 0, legend_title = NA, use_shapes = FALSE){
  EZ <- point_estimate_Z(fit, raw = TRUE)
  allz <- fit$zraw
  for(i in 1:(dim(fit$z)[3])){
    allz[,,i] <- .procrust(allz[,,i], EZ)
  }
  A <- fit$A

  posdat <- data.frame(x = rep(NA, prod(dim(allz)[c(1,3)])), y = NA, node = NA)
  k <- 0
  for(i in node_subset){
    posdat$x[(k+1):(k+(dim(allz)[3]))] <- allz[i,1,]
    posdat$y[(k+1):(k+(dim(allz)[3]))] <- allz[i,2,]
    posdat$node[(k+1):(k+(dim(allz)[3]))] <- i
    k <- k + (dim(allz)[3])
  }
  if(nodes_colored_by_id == F){
    node_ids <- as.factor(rep(1, length(node_ids)))
  }

  ztrue <- EZ
  dfnodes <- data.frame(x = ztrue[node_subset,1], y = ztrue[node_subset,2], node_ids = node_ids[node_subset])

  p <- ggplot2::ggplot(dfnodes, ggplot2::aes(x = .data$x, y = .data$y))
  if(show_edges == T){
    empt <- rep(NA, sum(A))
    dfedges <- data.frame(xstart = empt, xend = empt, ystart = empt, yend = empt)
    edgelist <- data.frame(v1 = c(), v2 = c())
    for(i in node_subset){
      edges <- node_subset[A[i,node_subset] == 1]
      if(length(edges) > 0){
        nex <- cbind(v1 = i, v2 = edges)
        edgelist <- rbind(edgelist, nex)
      }
    }
    for(i in 1:length(empt)){
      dfedges[i,] <- c(ztrue[edgelist[i,1], 1], ztrue[edgelist[i,2], 1], ztrue[edgelist[i,1], 2], ztrue[edgelist[i,2], 2])
    }
    dfedges <- dfedges[dfedges$yend > dfedges$ystart,]
    p <- p + ggplot2::geom_curve(data = dfedges, ggplot2::aes(x = .data$xstart, y = .data$ystart, xend = .data$xend, yend = .data$yend), curvature = edge_curve, color = edge_color, size = edge_size)
  }


  if(is.factor(node_ids)){
    if(length(node_palette) != length(unique(node_ids))){
      if(!is.na(node_palette[1])){
        print("Incorrect length node_palette supplied. Using default.")
        node_palette <- NA
      }
    }
    if(is.na(node_palette[1])){
      if(length(unique(node_ids)) <= 2){
        aaa <- c("#00C7FC", "red")
      }else if(length(unique(node_ids)) <= 11){
        aaa <- RColorBrewer::brewer.pal(length(unique(node_ids)),"Spectral")
      }else{
        colfunc <- colorRampPalette(c("red","yellow","springgreen","royalblue"))
        aaa <- colfunc(length(unique(node_ids)))
      }
    }else{
      aaa <- node_palette
    }
    names(aaa) <- as.factor(unique(node_ids))
    if(use_shapes){
      nodelen <- length(unique(node_ids))
      bbb <- rep(21:25, length.out = nodelen)
      names(bbb) <- names(aaa)
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids, shape = .data$node_ids), colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p +  ggplot2::scale_fill_manual(name = legend_title, values= aaa) + ggplot2::scale_shape_manual(name = legend_title, values = bbb)
    }else{
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p +  ggplot2::scale_fill_manual(values= aaa)
    }
  }else{
    p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
    p <- p + ggplot2::scale_fill_distiller(palette = "Spectral")
  }
  p <- p + ggplot2::theme_bw() + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank()) + ggplot2::xlab("Z1") + ggplot2::ylab("Z2")
  if(is.na(legend_title) == T){
    p <- p + ggplot2::theme(legend.position="none")
  }else{
    p <- p + ggplot2::labs(fill = legend_title)
  }
  extreme <- 4/3 * max(abs(EZ))
  p <- p + ggplot2::xlim(c(-extreme, extreme)) + ggplot2::ylim(c(-extreme, extreme))
  # add in uncertainty
  if(is.factor(node_ids)){
    for(i in uncertainty_subset){
      p <-  p + ggplot2::geom_density_2d(data = posdat[posdat$node %in% c(i),], ggplot2::aes(x =.data$x, y = .data$y), color = aaa[node_ids[i]], alpha = 1.0)
      p$layers <- append(p$layers[[length(p$layers)]], p$layers[1:(length(p$layers) - 1)])
    }
  }else{
    colfunc2 <- colorRampPalette(RColorBrewer::brewer.pal(7,"Spectral"))
    nn <- 50
    rr <- rev(colfunc2(nn))
    opts <- node_ids[node_subset]
    mmn <- min(opts)
    mmx <- max(opts)
    for(i in uncertainty_subset){
      thecol <- rr[min(floor(nn * (node_ids[i] - mmn)/(mmx - mmn)) + 1, nn)]
      p <-  p + ggplot2::geom_density_2d(data =  posdat[posdat$node %in% c(i),], ggplot2::aes(x = .data$x, y = .data$y), color = thecol, alpha = 1.0)
      p$layers <- append(p$layers[[length(p$layers)]], p$layers[1:(length(p$layers) - 1)])
    }
  }
  return(p)
}


plotNetworkTemporal <- function(A, timepoints, z = cbind(cos(2 * pi * (1:nrow(A))/nrow(A)), sin(2 * pi * (1:nrow(A))/nrow(A))), node_ids = as.factor(1:nrow(z)), node_color = c("#00C7FC"), node_size = 3, nodes_colored_by_id = F, node_palette = NA, show_edges = T, edge_color = "black", edge_size = 0.5, edge_curve = 0, show_axes = T, legend_title = NA, use_shapes = FALSE){

  ztrue <- z
  dfnodes <- data.frame(x = ztrue[,1], y = ztrue[,2], node_ids = node_ids, timepoint = timepoints)

  p <- ggplot2::ggplot(dfnodes, ggplot2::aes(x = .data$x, y = .data$y))
  if(show_edges == T){
    empt <- rep(NA, sum(A))
    dfedges <- data.frame(xstart = empt, xend = empt, ystart = empt, yend = empt, timepoint = empt)
    edgelist <- data.frame(v1 = c(), v2 = c())
    for(i in 1:nrow(A)){
      edges <- (1:nrow(A))[A[i,] == 1]
      if(length(edges) > 0){
        nex <- cbind(v1 = i, v2 = edges, timepoint = timepoints[i])
        edgelist <- rbind(edgelist, nex)
      }
    }
    for(i in 1:length(empt)){
      dfedges[i,] <- c(ztrue[edgelist[i,1], 1], ztrue[edgelist[i,2], 1], ztrue[edgelist[i,1], 2], ztrue[edgelist[i,2], 2], edgelist$timepoint[i])
    }
    dfedges <- dfedges[dfedges$yend > dfedges$ystart,]
    p <- p + ggplot2::geom_curve(data = dfedges, ggplot2::aes(x = .data$xstart, y = .data$ystart, xend = .data$xend, yend = .data$yend), curvature = edge_curve, color = edge_color, size = edge_size)
  }
  if(nodes_colored_by_id == F){
    p <- p +  ggplot2::geom_point(shape = 21, colour = "black", fill = node_color, size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
  }else{
    if(is.factor(node_ids)){
      if(length(node_palette) != length(unique(node_ids))){
        if(!is.na(node_palette[1])){
          print("Incorrect length node_palette supplied. Using default.")
          node_palette <- NA
        }
      }
      if(is.na(node_palette[1])){
        if(length(unique(node_ids)) <= 2){
          aaa <- c("#00C7FC", "red")
        }else if(length(unique(node_ids)) <= 11){
          aaa <- RColorBrewer::brewer.pal(length(unique(node_ids)),"Spectral")
        }else{
          colfunc <- colorRampPalette(c("red","yellow","springgreen","royalblue"))
          aaa <- colfunc(length(unique(node_ids)))
        }
      }else{
        aaa <- node_palette
      }
      names(aaa) <- as.factor(unique(node_ids))
      if(use_shapes){
        nodelen <- length(unique(node_ids))
        bbb <- rep(21:25, length.out = nodelen)
        names(bbb) <- names(aaa)
        p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids, shape = .data$node_ids), colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
        p <- p +  ggplot2::scale_fill_manual(name = legend_title, values= aaa) + ggplot2::scale_shape_manual(name = legend_title, values = bbb)
      }else{
        p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
        p <- p +  ggplot2::scale_fill_manual(values= aaa)
      }
    }else{
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p + ggplot2::scale_fill_distiller(palette = "Spectral")
    }
  }
  if(show_axes == F){
    p <- p + ggplot2::theme(axis.line=ggplot2::element_blank(),axis.text.x=ggplot2::element_blank(),
                   axis.text.y=ggplot2::element_blank(),axis.ticks=ggplot2::element_blank(),
                   axis.title.x=ggplot2::element_blank(),
                   axis.title.y=ggplot2::element_blank(),
                   panel.background=ggplot2::element_blank(),panel.border=ggplot2::element_blank(),panel.grid.major=ggplot2::element_blank(),
                   panel.grid.minor=ggplot2::element_blank(),plot.background=ggplot2::element_blank())
    if(is.na(legend_title) == T){
      p <- p + ggplot2::theme(legend.position="none")
    }

  }else{
    p <- p + ggplot2::theme_bw() + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank()) + ggplot2::xlab("Z1") + ggplot2::ylab("Z2")
    if(is.na(legend_title) == T){
      p <- p + ggplot2::theme(legend.position="none")
    }else{
      p <- p + ggplot2::labs(fill = legend_title)
    }
  }
  extreme <- 4/3 * max(abs(z))
  p <- p + ggplot2::xlim(c(-extreme, extreme)) + ggplot2::ylim(c(-extreme, extreme))
  return(p + ggplot2::facet_wrap(~.data$timepoint))
}


plotNetworkFitTemporal <- function(fit, timepoints = fit$timepoints, node_subset = 1:nrow(fit$A), uncertainty_subset = c(), node_ids = fit$node_ids, nodes_colored_by_id = T, node_size = 3, node_palette = NA, show_edges = T, edge_color = "black", edge_size = 0.5, edge_curve = 0, legend_title = NA, use_shapes = FALSE){
  EZ <- point_estimate_Z(fit, raw = TRUE)
  allz <- fit$zraw
  for(i in 1:(dim(fit$z)[3])){
    allz[,,i] <- .procrust(allz[,,i], EZ)
  }
  A <- fit$A

  posdat <- data.frame(x = rep(NA, prod(dim(allz)[c(1,3)])), y = NA, node = NA, timepoint = NA)
  k <- 0
  for(i in node_subset){
    posdat$x[(k+1):(k+(dim(allz)[3]))] <- allz[i,1,]
    posdat$y[(k+1):(k+(dim(allz)[3]))] <- allz[i,2,]
    posdat$node[(k+1):(k+(dim(allz)[3]))] <- i
    posdat$timepoint[(k+1):(k+(dim(allz)[3]))] <- timepoints[i]
    k <- k + (dim(allz)[3])
  }

  ztrue <- EZ
  dfnodes <- data.frame(x = ztrue[node_subset,1], y = ztrue[node_subset,2], node_ids = node_ids[node_subset], timepoint = timepoints[node_subset])

  p <- ggplot2::ggplot(dfnodes, ggplot2::aes(x = .data$x, y = .data$y))
  if(show_edges == T){
    empt <- rep(NA, sum(A))
    dfedges <- data.frame(xstart = empt, xend = empt, ystart = empt, yend = empt, timepoint = empt)
    edgelist <- data.frame(v1 = c(), v2 = c())
    for(i in node_subset){
      edges <- node_subset[A[i,node_subset] == 1]
      if(length(edges) > 0){
        nex <- cbind(v1 = i, v2 = edges, timepoint = timepoints[i])
        edgelist <- rbind(edgelist, nex)
      }
    }
    for(i in 1:length(empt)){
      dfedges[i,] <- c(ztrue[edgelist[i,1], 1], ztrue[edgelist[i,2], 1], ztrue[edgelist[i,1], 2], ztrue[edgelist[i,2], 2], edgelist$timepoint[i])
    }
    dfedges <- dfedges[dfedges$yend > dfedges$ystart,]
    p <- p + ggplot2::geom_curve(data = dfedges, ggplot2::aes(x = .data$xstart, y = .data$ystart, xend = .data$xend, yend = .data$yend), curvature = edge_curve, color = edge_color, size = edge_size)
  }
  if(nodes_colored_by_id == F){
    node_ids <- as.factor(rep(1, length(node_ids))) # set them all equal to the default color
  }
  if(is.factor(node_ids)){
    if(length(node_palette) != length(unique(node_ids))){
      if(!is.na(node_palette[1])){
        print("Incorrect length node_palette supplied. Using default.")
        node_palette <- NA
      }
    }
    if(is.na(node_palette[1])){
      if(length(unique(node_ids)) <= 2){
        aaa <- c("#00C7FC", "red")
      }else if(length(unique(node_ids)) <= 11){
        aaa <- RColorBrewer::brewer.pal(length(unique(node_ids)),"Spectral")
      }else{
        colfunc <- colorRampPalette(c("red","yellow","springgreen","royalblue"))
        aaa <- colfunc(length(unique(node_ids)))
      }
    }else{
      aaa <- node_palette
    }
    names(aaa) <- as.factor(unique(node_ids))
    if(use_shapes){
      nodelen <- length(unique(node_ids))
      bbb <- rep(21:25, length.out = nodelen)
      names(bbb) <- names(aaa)
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids, shape = .data$node_ids), colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p +  ggplot2::scale_fill_manual(name = legend_title, values= aaa) + ggplot2::scale_shape_manual(name = legend_title, values = bbb)
    }else{
      p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
      p <- p +  ggplot2::scale_fill_manual(values= aaa)
    }
  }else{
    p <- p +  ggplot2::geom_point(ggplot2::aes(fill = .data$node_ids) , shape = 21, colour = "black", size = node_size, stroke = node_size/5.5) + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank())
    p <- p + ggplot2::scale_fill_distiller(palette = "Spectral")
  }
  p <- p + ggplot2::theme_bw() + ggplot2::theme(panel.grid.major = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank()) + ggplot2::xlab("Z1") + ggplot2::ylab("Z2")
  if(is.na(legend_title) == T){
    p <- p + ggplot2::theme(legend.position="none")
  }else{
    p <- p + ggplot2::labs(fill = legend_title)
  }
  extreme <- 4/3 * max(abs(EZ))
  p <- p + ggplot2::xlim(c(-extreme, extreme)) + ggplot2::ylim(c(-extreme, extreme))
  # add in uncertainty
  if(is.factor(node_ids)){
    for(i in uncertainty_subset){
      p <-  p + ggplot2::geom_density_2d(data =  posdat[posdat$node %in% c(i),], ggplot2::aes(x = .data$x, y = .data$y), color = aaa[node_ids[i]], alpha = 1.0)
      p$layers <- append(p$layers[[length(p$layers)]], p$layers[1:(length(p$layers) - 1)])
    }
  }else{
    colfunc2 <- colorRampPalette(RColorBrewer::brewer.pal(7,"Spectral"))
    nn <- 50
    rr <- rev(colfunc2(nn))
    opts <- node_ids[node_subset]
    mmn <- min(opts)
    mmx <- max(opts)
    for(i in uncertainty_subset){
      thecol <- rr[min(floor(nn * (node_ids[i] - mmn)/(mmx - mmn)) + 1, nn)]
      p <-  p + ggplot2::geom_density_2d(data =  posdat[posdat$node %in% c(i),], ggplot2::aes(x = .data$x, y = .data$y), color = thecol, alpha = 1.0)
      p$layers <- append(p$layers[[length(p$layers)]], p$layers[1:(length(p$layers) - 1)])
    }
  }
  return(p + ggplot2::facet_wrap(~.data$timepoint))
}
