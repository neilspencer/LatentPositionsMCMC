#' Compute a point estimate of Z
#'
#' Uses the MCMC output in \code{"fit"} to obtain a point estimate of the latent positions Z. The point estimate is calculated by computing the posterior expectation of the matrix of squared distances between the latent positions, then using multidimensional scaling to determine the \code{"d"}-dimensional latent positions to best approximate it.
#'
#' @param fit The list output from a run of \code{"posterior_inference_LPM"}, \code{"posterior_inference_LPM_continuation"}, or \code{"posterior_inference_LPM_temporal"}
#' @param raw A boolean indicating whether to estimate the raw latent positions or the reparameterized latent positions corresponding to \code{"gamma = 1"}
#' @param d The desired dimension of the latent positions.
#'
#' @return A n by d matrix representing the estimate of the latent positions (n denotes the number of nodes)
#'
#' @export
point_estimate_Z <- function(fit, raw = TRUE, d = 2){
  if(raw){
    alldist <- as.matrix(dist(fit$zraw[,,1]))^2
    nruns <- dim(fit$zraw)[3]
    for(i in 2:nruns){
      alldist <- alldist + as.matrix(dist(fit$zraw[,,i]))^2
    }
    alldist <- alldist/nruns
    J <- diag(nrow(fit$A)) - 1/nrow(fit$A)
    B <- -0.5 * J %*% alldist %*% J
    xx <- eigen(B)
    Z <- (xx$vectors[,1:d] * rep(sqrt(xx$values[1:d]), each = nrow(fit$A)))
    return(Z)
  }else{
    alldist <- as.matrix(dist(fit$z[,,1]))^2
    nruns <- dim(fit$z)[3]
    for(i in 2:nruns){
      alldist <- alldist + as.matrix(dist(fit$z[,,i]))^2
    }
    alldist <- alldist/nruns
    J <- diag(nrow(fit$A)) - 1/nrow(fit$A)
    B <- -0.5 * J %*% alldist %*% J
    xx <- eigen(B)
    Z <- (xx$vectors[,1:d] * rep(sqrt(xx$values[1:d]), each = nrow(fit$A)))
    return(Z)
  }

}
