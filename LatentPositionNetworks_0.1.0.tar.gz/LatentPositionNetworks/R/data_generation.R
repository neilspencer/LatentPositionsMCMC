createA <- function(Alabels, tau, priorprecision, gamma2, d = 2){
  sigma2inv = gamma2
  ztrue <- t(mvtnorm::rmvnorm(d, sigma = 1/sigma2inv * solve(priorprecision)))
  nnodes <- nrow(Alabels)
  A <- matrix(0, nrow = nnodes, ncol = nnodes)
  diag(A) <- 0
  for(i in 1:(nnodes - 1)){
    for(j in (i + 1):nnodes){
      if(Alabels[i, j] != -1){
        A[i, j] <- stats::rbinom(1, 1, tau[1 + Alabels[i,j]] * exp(-0.5 *  t(ztrue[i, ] - ztrue[j,]) %*% (ztrue[i,] - ztrue[j,]) ))
        A[j, i] <- A[i, j]
      }
    }
  }
  return(list(A = A, z = ztrue, zraw = ztrue * sqrt(gamma2)))
}

createtemporalA <- function(nnodes, ntimes, rho, tau, gamma2, d = 2){
  sigma2inv = gamma2
  priorprecision <- priorMatrix_temporal(nnodes, ntimes, rho)
  ztrue <- t(mvtnorm::rmvnorm(d, sigma = sigma2inv * solve(priorprecision)))
  A <- matrix(0, nrow = nnodes * ntimes, ncol = nnodes * ntimes)
  Alabels <- matrix(-1, nrow = nnodes * ntimes, ncol = nnodes * ntimes)

  for(i in 1:(nnodes - 1)){
    for(j in (i + 1):nnodes){
      for(t in 1:(ntimes - 1)){
        if(Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes] == -1){
          Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes] <- 0
          Alabels[j + (t - 1) * nnodes, i + (t - 1) * nnodes] <- 0
        }
        A[i + (t - 1) * nnodes, j + (t - 1) * nnodes] <- stats::rbinom(1, 1, tau[1 + Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes]] * exp(-0.5 *  t(ztrue[i+ (t - 1) * nnodes, ] - ztrue[j+ (t - 1) * nnodes,]) %*% (ztrue[i+ (t - 1) * nnodes,] - ztrue[j+ (t - 1) * nnodes,]) ))
        A[j + (t - 1) * nnodes, i + (t - 1) * nnodes] <- A[i + (t - 1) * nnodes, j + (t - 1) * nnodes]
        if(A[i + (t - 1) * nnodes, j + (t - 1) * nnodes] == 1){
          Alabels[i + t * nnodes, j + t * nnodes] <- 1
          Alabels[j + t * nnodes, i + t * nnodes] <- 1
        }
      }
      t <- ntimes
      if(Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes] == -1){
        Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes] <- 0
        Alabels[j + (t - 1) * nnodes, i + (t - 1) * nnodes] <- 0
      }
      A[i + (t - 1) * nnodes, j + (t - 1) * nnodes] <- stats::rbinom(1, 1, tau[1 + Alabels[i + (t - 1) * nnodes, j + (t - 1) * nnodes]] * exp(-0.5 *  t(ztrue[i+ (t - 1) * nnodes, ] - ztrue[j+ (t - 1) * nnodes,]) %*% (ztrue[i+ (t - 1) * nnodes,] - ztrue[j+ (t - 1) * nnodes,]) ))
      A[j + (t - 1) * nnodes, i + (t - 1) * nnodes] <- A[i + (t - 1) * nnodes, j + (t - 1) * nnodes]
    }
  }
  return(list(A = A, Alabels = Alabels, ztrue = ztrue, priorprecision = priorprecision))
}

