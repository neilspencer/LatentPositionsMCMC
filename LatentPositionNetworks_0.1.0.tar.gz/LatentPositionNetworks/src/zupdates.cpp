#include <RcppArmadillo.h>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
#include "common.h"

// updates latent positions according to split HMC using inverse of the precision.
List zupdate_splitHMC(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, arma::mat gaussmat_inv, double pdf_old){
  int n = z.n_rows;
  int d = z.n_cols;

  // sample initial momentum from N(0, gauss_mat)
  arma::mat s0 = rmvnorm_prec(d, n, gaussmat_inv);

  // beginning leapfrog step
  arma::mat znew = z;
  arma::mat snew = gaussmat_inv * (s0 - eps/2.0 *  (gradient_nogaussian_categorical(znew, dyads, 1.0, tau)));

  for(int step = 0; step < L; ++step){
    arma::mat a = snew;
    arma::mat b = znew;
    znew = a * sin(eps) + b * cos(eps);
    snew = a * cos(eps) - b * sin(eps);

    // update momentum
    if(step != (L - 1)){
      snew = snew - eps * gaussmat_inv * (gradient_nogaussian_categorical(znew, dyads, 1.0, tau));
    }
  }

  //final partial momentum update ( and switch back to proper scale)
  snew = gaussmat * snew - eps/2 * (gradient_nogaussian_categorical(znew, dyads, 1.0, tau));

  // calculate the metropolis hastings ratio
  double pdf =  ld_all_categorical(znew, dyads, 1.0, tau, gaussmat);

  arma::mat mom_pre(1,1);
  arma::mat mom_post(1,1);

  mom_pre(0,0) = 0;
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_pre = mom_pre + ((s0.col(i)).t()) * gaussmat_inv * (s0.col(i));
    mom_post = mom_post + ((snew.col(i)).t()) * gaussmat_inv * (snew.col(i));
  }
  double MH =  pdf - 0.5 * mom_post(0,0) - pdf_old + 0.5 * mom_pre(0,0);
  if(MH > log(R::runif(0,1))){
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "accept " << std::endl;
    pdf_old = pdf;
    z = znew;
  }
  else{
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "reject " << std::endl;
  }
  return(List::create(z, pdf_old));
}

// updates latent positions according to split HMC using cholesky decomposition to solve linear systems.
List zupdate_splitHMCchol(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, double pdf_old){
  int n = z.n_rows;
  int d = z.n_cols;
  arma::mat R = arma::chol(gaussmat);
  // sample initial momentum from N(0, gauss_mat_inv)
  arma::mat s0 = rmvnorm_precchol(d, n, R);

  // beginning leapfrog step
  arma::mat znew = z;
  arma::mat grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
  arma::mat snew = s0 - eps/2.0 *  chol_solve2(R, grd);

  double sineps = sin(eps);
  double coseps = cos(eps);
  for(int step = 0; step < L; ++step){
    arma::mat a = snew;
    arma::mat b = znew;
    znew = a * sineps + b * coseps;
    snew = a * coseps - b * sineps;

    // update momentum
    if(step != (L - 1)){
      grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
      snew = snew - eps * chol_solve2(R, grd);
    }
  }

  //final partial momentum update ( and switch back to proper scale)
  grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
  snew = snew - eps/2 * chol_solve2(R, grd);

  // calculate the metropolis hastings ratio
  double pdf =  ld_all_categorical(znew, dyads, 1.0, tau, gaussmat);

  arma::mat mom_pre(1,1);
  arma::mat mom_post(1,1);

  mom_pre(0,0) = 0;
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_pre = mom_pre + ((s0.col(i)).t()) * gaussmat * (s0.col(i));
    mom_post = mom_post + ((snew.col(i)).t()) * gaussmat * (snew.col(i));
  }
  double MH =  pdf - 0.5 * mom_post(0,0) - pdf_old + 0.5 * mom_pre(0,0);
  if(MH > log(R::runif(0,1))){
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "accept " << std::endl;
    pdf_old = pdf;
    z = znew;
  }
  else{
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "reject " << std::endl;
  }
  return(List::create(z, pdf_old));
}


// updates latent positions according to split HMC using cholesky decomposition to solve linear systems.
List zupdate_splitHMCprechol(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, double pdf_old, arma::mat R){
  int n = z.n_rows;
  int d = z.n_cols;
  // sample initial momentum from N(0, gauss_mat_inv)
  arma::mat s0 = rmvnorm_precchol(d, n, R);

  // beginning leapfrog step
  arma::mat znew = z;
  arma::mat grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
  arma::mat snew = s0 - eps/2.0 *  chol_solve2(R, grd);

  double sineps = sin(eps);
  double coseps = cos(eps);
  for(int step = 0; step < L; ++step){
    arma::mat a = snew;
    arma::mat b = znew;
    znew = a * sineps + b * coseps;
    snew = a * coseps - b * sineps;

    // update momentum
    if(step != (L - 1)){
      grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
      snew = snew - eps * chol_solve2(R, grd);
    }
  }

  //final partial momentum update ( and switch back to proper scale)
  grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
  snew = snew - eps/2 * chol_solve2(R, grd);

  // calculate the metropolis hastings ratio
  double pdf =  ld_all_categorical(znew, dyads, 1.0, tau, gaussmat);

  arma::mat mom_pre(1,1);
  arma::mat mom_post(1,1);

  mom_pre(0,0) = 0;
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_pre = mom_pre + ((s0.col(i)).t()) * gaussmat * (s0.col(i));
    mom_post = mom_post + ((snew.col(i)).t()) * gaussmat * (snew.col(i));
  }
  double MH =  pdf - 0.5 * mom_post(0,0) - pdf_old + 0.5 * mom_pre(0,0);
  if(MH > log(R::runif(0,1))){
    pdf_old = pdf;
    z = znew;
  }
  return(List::create(z, pdf_old));
}

// updates latent positions according to leapfrog HMC.
List zupdate_HMC(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, arma::mat gaussmat_inv, double pdf_old){
  int n = z.n_rows;
  int d = z.n_cols;

  // sample initial momentum from N(0, gauss_mat)
  arma::mat s0 = rmvnorm_prec(d, n, gaussmat_inv);

  // beginning leapfrog step
  arma::mat znew = z;
  arma::mat snew = s0 - eps/2 * (gradient_all_categorical(znew, dyads, 1.0, tau, gaussmat));

  for(int step = 0; step < L; ++step){

    znew = znew + eps * gaussmat_inv * snew;

    // update momentum
    if(step != (L - 1)){
      snew = snew - eps * (gradient_all_categorical(znew, dyads, 1.0, tau, gaussmat));
    }
  }

  //final partial momentum update
  snew = snew - eps/2 * (gradient_all_categorical(znew, dyads, 1.0, tau, gaussmat));
  // calculate the metropolis hastings ratio
  double pdf =  ld_all_categorical(znew, dyads, 1.0, tau, gaussmat);

  arma::mat mom_pre(1,1);
  arma::mat mom_post(1,1);

  mom_pre(0,0) = 0;
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_pre = mom_pre + ((s0.col(i)).t()) * gaussmat_inv * (s0.col(i));
    mom_post = mom_post + ((snew.col(i)).t()) * gaussmat_inv * (snew.col(i));
  }
  double MH =  pdf - 0.5 * mom_post(0,0) - pdf_old + 0.5 * mom_pre(0,0);
  if(MH > log(R::runif(0,1))){
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "accept " << std::endl;
    pdf_old = pdf;
    z = znew;
  }
  else{
    //Rcpp::Rcout << exp(MH) << std::endl;
    //Rcpp::Rcout << "reject " << std::endl;
  }
  return(List::create(z, pdf_old));
}

// updates latent positions according to Elliptical Slice Sampling.
arma::mat zupdate_ellipticalslice(arma::mat z, arma::mat dyads, arma::vec tau, arma::mat gaussmat){
  int n = z.n_rows;
  int d = z.n_cols;
  ld_zz dens_z(dyads, tau, 1.0);
  z = ellipticalslicemat(z, gaussmat, n, d, &dens_z);
  return(z);
}

// updates latent positions according to Metropolis within Gibbs (with firefly).
List zupdate_metGibbs(arma::mat z, double rwsd, arma::mat connecteds, arma::mat disconnecteds, arma::vec connectednums, arma::vec disconnectednums, arma::mat gaussmat, arma::mat disconnectedthetaindices, arma::vec theta){
  int n = z.n_rows;
  int d = z.n_cols;
  arma::mat noise(n, d);
  for(int i = 0; i < d; ++i){
    noise.col(i) = rwsd * as<arma::vec>(rnorm(n));
  }
  for(int step = 0; step < n; ++step){
    arma::mat znew = z;
    znew.row(step) += noise.row(step);
    double MH = ldzi_firefly(step, znew, connecteds, connectednums[step], disconnecteds, disconnectednums[step], gaussmat, disconnectedthetaindices, theta) - ldzi_firefly(step, z, connecteds, connectednums[step], disconnecteds, disconnectednums[step], gaussmat, disconnectedthetaindices, theta);
    if(log(R::runif(0,1)) < MH){
      z.row(step) = znew.row(step);
    }
  }
  return(List::create(z));
}

// updates latent positions according to Metropolis within Gibbs (no Firefly).
List zupdate_metGibbsnoFF(arma::mat z, double rwsd, arma::mat connecteds, arma::mat disconnecteds, arma::vec connectednums, arma::vec disconnectednums, arma::mat gaussmat, arma::vec tau, arma::mat Alabels){
  int n = z.n_rows;
  int d = z.n_cols;
  arma::mat noise(n, d);
  for(int i = 0; i < d; ++i){
    noise.col(i) = rwsd * as<arma::vec>(rnorm(n));
  }
  for(int step = 0; step < n; ++step){
    arma::mat znew = z;
    znew.row(step) += noise.row(step);
    double MH = ldzi_nofirefly(step, Alabels, znew, connecteds, connectednums[step], disconnecteds, disconnectednums[step], tau, gaussmat) - ldzi_nofirefly(step, Alabels, z, connecteds, connectednums[step], disconnecteds, disconnectednums[step], tau, gaussmat);
    if(log(R::runif(0,1)) < MH){
      z.row(step) = znew.row(step);
    }
  }
  return(List::create(z));
}

// updates latent positions according to Elliptical Slice Sampling within Gibbs (with Firefly)
arma::mat zupdate_ellipticalsliceGibbs(arma::mat z, double sigma2inv, double sigma2inv_init, arma::mat premeans, arma::vec vars, arma::mat disconnecteds, arma::vec disconnectednums, arma::mat disconnectedthetaindices, arma::vec theta, arma::mat priorconnecteds, arma::vec priorconnectednums, arma::mat priorprecision){
  int n = z.n_rows;
  int d = z.n_cols;
  for(int i = 0; i < n; ++i){
    ld_zGibbs dens_zi(i, disconnecteds, disconnectednums[i], disconnectedthetaindices, theta, sigma2inv, sigma2inv_init, priorconnecteds, priorconnectednums, priorprecision);
    arma::vec means(d);
    for(int j = 0; j < d; ++j){
      means[j] = 0;
      for(int k = 0; k < n; ++k){
        means[j] = means[j] + premeans(i, k) * z(k, j);
      }
    }
    z = ellipticalsliceGibbs(z, i, means, vars[i], d, &dens_zi);
  }
  return(z);
}

// updates latent positions according to Elliptical Slice Sampling within Gibbs (no firefly)
arma::mat zupdate_ellipticalsliceGibbsnoFF(arma::mat z, double sigma2inv, double sigma2inv_init, arma::mat premeans, arma::vec vars, arma::mat disconnecteds, arma::vec disconnectednums, arma::vec tau, arma::mat priorconnecteds, arma::vec priorconnectednums, arma::mat priorprecision, arma::mat Alabels){
  int n = z.n_rows;
  int d = z.n_cols;
  for(int i = 0; i < n; ++i){
    ld_zGibbsnoFF dens_zi(i, disconnecteds, disconnectednums[i], tau, sigma2inv, sigma2inv_init, priorconnecteds, priorconnectednums, priorprecision, Alabels);

    //generate the matrices necessary to calculate the means
    arma::vec means(d);
    for(int j = 0; j < d; ++j){
      means[j] = 0;
      for(int k = 0; k < n; ++k){
        means[j] = means[j] + premeans(i, k) * z(k, j);
      }
    }
    z = ellipticalsliceGibbs(z, i, means, vars[i], d, &dens_zi);
  }
  return(z);
}


