#include <RcppArmadillo.h>
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"

using namespace Rcpp;

// could be sped up by saving squares of positions

// need to fix descendants and ancestors of points.
// the targetted density
double ldzi_firefly(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat gaussmat, arma::mat disconnectedthetaindices, arma::vec theta){
  double res = 0;
  double square = dot(z.row(i), z.row(i));
  for(int j =0; j < connectednum; ++j){
    res -= gaussmat(i, connecteds(i,j)) * dot(z.row(i), z.row(connecteds(i,j)));
  }
  res += 0.5 * gaussmat(i,i) * square;

  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    if(theta(disconnectedthetaindices(i, j)) == 1){
    res += log(1.0 - exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
    }
  }

  return(res);
}

double ldzi_nofirefly(int i, arma::mat Alabels, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::vec tau, arma::mat gaussmat){
  double res = 0;
  double square = dot(z.row(i), z.row(i));
  for(int j =0; j < connectednum; ++j){
    res -= gaussmat(i,connecteds(i,j)) * dot(z.row(i), z.row(connecteds(i,j)));
  }
  res += 0.5 * gaussmat(i,i) * square;

  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    res += log(1.0 - tau[Alabels(i, disconnecteds(i,j))] * exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
  }
  return(res);
}

