#ifndef firefly_h
#define firefly_h
#include <RcppArmadillo.h>
using namespace Rcpp;
arma::vec update_thetas(arma::vec thetas, arma::mat z, arma::mat dyads, double gamma2, double tau);
arma::vec update_thetas_categorical(arma::vec thetas, arma::mat z, arma::mat dyads, double gamma2, arma::vec tau);
#endif
