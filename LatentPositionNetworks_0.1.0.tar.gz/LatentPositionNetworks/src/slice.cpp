#include "slice.h"

arma::mat ellipticalslicemat(arma::mat Z, arma::mat Sigma, int n, int d, logdensityellipsemat* logL) {
  arma::mat v(n,d);
  for(int i = 0; i < d; ++i){
    v.col(i) = rmvnorm_prec(1, n, Sigma);
  }

  double pi = 3.1415926535897;
  double logLf = logL->val(Z);
  double logy = logLf - R::rexp(1.);
  double theta = R::runif(0., 2 * pi);
  double theta_min = theta - 2 * pi;
  double theta_max = theta;
  arma::mat fnew;


  while(true) {
    R_CheckUserInterrupt();
    fnew = Z * cos(theta) + v * sin(theta);
    double logLfnew = logL->val(fnew);
    if(logLfnew>=logy) { break; }
    if(theta < 0) {
      theta_min = theta;
    } else {
      theta_max = theta;
    }
    theta = R::runif(theta_min, theta_max);
  }

  return(fnew);
}

arma::mat ellipticalsliceGibbs(arma::mat z, int i, arma::vec meani, double vari, int d, logdensityellipseGibbs* logL) {
  arma::vec fold(d);
  arma::vec f(d);
  for(int k = 0; k < d; ++k){
    fold(k) = z(i, k) - meani[k];
    f(k) = R::rnorm(0, sqrt(vari));
  }
  double pi = 3.1415926535897;
  double logLf = logL->val(z);
  double logy = logLf - R::rexp(1.);
  double theta = R::runif(0., 2 * pi);
  double theta_min = theta - 2 * pi;
  double theta_max = theta;
  arma::vec fnew;


  while(true) {
    R_CheckUserInterrupt();
    fnew = fold * cos(theta) + f * sin(theta);
    for(int k = 0; k < d; ++k){
      z(i, k) = fnew[k] + meani[k];
    }
    double logLfnew = logL->val(z);
    if(logLfnew>=logy) { break; }
    if(theta < 0) {
      theta_min = theta;
    } else {
      theta_max = theta;
    }
    theta = R::runif(theta_min, theta_max);
  }

  return(z);
}
