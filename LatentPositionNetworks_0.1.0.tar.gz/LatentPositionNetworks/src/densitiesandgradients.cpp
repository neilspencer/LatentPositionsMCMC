#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "densitiesandgradients.h"
#include "helperobjects.h"

using namespace Rcpp;

// the non-gaussian part of the targetted density
double ld_nogaussian(arma::mat z, arma::mat dyads, double gamma2, double tau){

  // save time by pre-computing the squares (I assume we use each at least once)
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;

  double result = 0;
  for(int i = 0; i < ndyads; ++i){
    result += log(1 - tau * exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1))))));
  }
  return(result);
}

// the non-gaussian part of the targetted density
double ld_nogaussian_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau){

  // save time by pre-computing the squares (I assume we use each at least once)
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;

  double result = 0;
  for(int i = 0; i < ndyads; ++i){
    result += log(1 - tau[dyads(i,2)] * exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1))))));
  }
  return(result);
}

// the gaussian part of the targetted density
double ld_gaussian(arma::mat z, arma::mat gaussmat){
  arma::mat zzt = z * z.t();
  int n = z.n_rows;
  double res = 0;
  for(int i = 0; i < n; ++i)
  {
    res += dot(zzt.row(i), gaussmat.col(i));
  }
  res = -res/2.0;
  return(res);
}

// the targetted density
double ld_all(arma::mat z, arma::mat dyads, double gamma2, double tau, arma::mat gaussmat){
  return(ld_gaussian(z, gaussmat) + ld_nogaussian(z, dyads, gamma2, tau));
}

// the targetted density
double ld_all_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau, arma::mat gaussmat){
  return(ld_gaussian(z, gaussmat) + ld_nogaussian_categorical(z, dyads, gamma2, tau));
}

// Calculate the gradient of the non-gaussian part.
arma::mat gradient_nogaussian(arma::mat z, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              double tau // the probability of an edge at distance 0
) {
  int nnodes = z.n_rows;
  int d = z.n_cols;
  int ndyads = dyads.n_rows;
  arma::mat ret(nnodes, d);
  ret.zeros();
  arma::vec squares(nnodes);
  for(int i = 0; i < nnodes; ++i){
    squares(i) = dot(z.row(i), z.row(i));
  }

  for(int i = 0; i < ndyads; ++i){
    double front = -1.0/(gamma2 *(exp(0.5/gamma2 * (squares(dyads(i,0)) + squares(dyads(i,1)) - 2 * dot(z.row(dyads(i,0)), z.row(dyads(i,1)))))/tau - 1));
    for(int j = 0; j < d; ++j){
      double entry = front * (z(dyads(i,0), j) - z(dyads(i,1), j));
      ret(dyads(i, 0), j) = ret(dyads(i,0), j) + entry;
      ret(dyads(i, 1), j) = ret(dyads(i,1), j) - entry;
    }
  }
  return ret;
}

// Calculate the gradient of the non-gaussian part.
arma::mat gradient_nogaussian_categorical(arma::mat z, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              arma::vec tau // the probability of an edge at distance 0
) {
  int nnodes = z.n_rows;
  int d = z.n_cols;
  int ndyads = dyads.n_rows;
  arma::mat ret(nnodes, d);
  ret.zeros();
  arma::vec squares(nnodes);
  for(int i = 0; i < nnodes; ++i){
    squares(i) = dot(z.row(i), z.row(i));
  }

  for(int i = 0; i < ndyads; ++i){
    double front = -1.0/(gamma2 *(exp(0.5/gamma2 * (squares(dyads(i,0)) + squares(dyads(i,1)) - 2 * dot(z.row(dyads(i,0)), z.row(dyads(i,1)))))/tau(dyads(i,2)) - 1));
    for(int j = 0; j < d; ++j){
      double entry = front * (z(dyads(i,0), j) - z(dyads(i,1), j));
      ret(dyads(i, 0), j) = ret(dyads(i,0), j) + entry;
      ret(dyads(i, 1), j) = ret(dyads(i,1), j) - entry;
    }
  }
  return ret;
}


arma::mat gradient_all(arma::mat z_, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              double tau, // the probability of an edge at distance 0
                              arma::mat gaussmat
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  arma::mat ret(nnodes, d);

  ret = gradient_nogaussian(z_, dyads, gamma2, tau);

  // add gaussian part
  ret = ret + gaussmat * z_;

  return ret;
}

arma::mat gradient_all_categorical(arma::mat z_, // the latent positions
                       arma::mat dyads, // the dyads without edges to consider
                       double gamma2, // the variance of the link function
                       arma::vec tau, // the probability of an edge at distance 0
                       arma::mat gaussmat
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  arma::mat ret(nnodes, d);

  ret = gradient_nogaussian_categorical(z_, dyads, gamma2, tau);

  // add gaussian part
  ret = ret + gaussmat * z_;

  return ret;
}

// [[Rcpp::export]]
arma::mat MLE_initialize(arma::mat A,
                     arma::mat Alabels,
                     arma::mat prior,
                    arma::mat z_init,
                    arma::vec tau,
                    double gamma2,
                    double eps = 0.01,
                    int niterations = 100
) {
  double sigma2inv = gamma2;
  int ntaus = tau.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::mat z = z_init; // initialize the z matrix
  arma::mat Laplacian = getLaplacian(A);

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  int ndyads = dyads.n_rows; // the number of dyads
  arma::mat gaussmat = Laplacian + sigma2inv * prior;
  for(int i = 0; i < niterations; i++){
    z = z - eps* gradient_all_categorical(z, dyads, 1.0, tau, gaussmat);
    double ll2 = ld_all_categorical(z, dyads, 1.0, tau, gaussmat);
  }
  return z;
}

//the prior on sigma2inv
double ld_sigma2inv(double sigma2inv, double param1, double param2){
  double lsigma2inv = (param1 - 1) * log(sigma2inv) - param2 * sigma2inv;
  return(lsigma2inv);
}

// the prior on tau
double ld_tau(arma::vec tau, arma::vec beta1, arma::vec beta2){
  double ltau = 0;
  for(int i = 0; i < tau.size(); ++i){
    ltau = ltau + (beta1[i] - 1) * log(tau[i]) + (beta2[i] - 1) * log(1 - tau[i]);
  }
  return(ltau);
}

// the density of theta given tau
double ld_theta(arma::vec tau, arma::vec nthetas0cat, arma::vec nthetas1cat){
  double ltheta = 0;
  for(int i = 0; i < tau.size(); ++i){
    ltheta += log(tau[i]) * nthetas1cat[i] + log(1 - tau[i]) * nthetas0cat[i];
  }
  return(ltheta);
}
