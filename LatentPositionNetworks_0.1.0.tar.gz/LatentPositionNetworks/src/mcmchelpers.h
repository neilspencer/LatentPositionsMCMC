#ifndef mcmchelpers_h
#define mcmchelpers_h
#include <RcppArmadillo.h>
#include "densitiesandgradients.h"
#include "firefly.h"

using namespace Rcpp;

// the targetted density
double ldrow_logistic(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat lineage, double sigma2, double delta2, double alpha);
double ldzi_nofirefly(int i, arma::mat Alabels, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::vec tau, arma::mat gaussmat);
double ldzi_firefly(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat gaussmat, arma::mat disconnectedthetaindices, arma::vec theta);

#endif
