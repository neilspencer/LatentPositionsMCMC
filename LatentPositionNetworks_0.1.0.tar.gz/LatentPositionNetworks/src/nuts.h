#ifndef nuts_h
#define nuts_h
#include <RcppArmadillo.h>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
using namespace Rcpp;
arma::mat nuts(arma::mat z, double eps, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax);
arma::mat nutsR(arma::mat z, double eps, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax, arma::mat R);
List buildtree(arma::mat z, arma::mat s, double logu, double v, double j, double eps, arma::mat R, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax);
#endif
