getdistancesmat <- function(z, burnin, nbenches, seedit){
  nruns <- dim(z)[3]
  d <- dim(z)[2]
  nnodes <- dim(z)[1]
  gamma2 <- 1
  # Make sure they all converged
  set.seed(seedit)
  # Choose the number of trial dyads
  alloptions <- cbind(1:nnodes, rep(1:nnodes, each = nnodes))
  alloptions <- alloptions[alloptions[,1] < alloptions[,2],]

  sampledyadindices <- sample(1:((nnodes^2- nnodes)/2), nbenches, replace = F)
  innodes <- alloptions[sampledyadindices, 1]
  outnodes <- alloptions[sampledyadindices, 2]

  dists <- getdistances(innodes, outnodes, z, nruns, nbenches, d)
  dat <- data.frame(iteration = rep(1:nruns, each = nbenches), dyad = as.factor(rep(1:nbenches, nruns)), distances = c(dists))

  dists <- getdistances(innodes, outnodes, z, nruns, nbenches, d)
  dat <- data.frame(iteration = rep(1:nruns, each = nbenches), dyad = as.factor(rep(1:nbenches, nruns)), distances = c(dists))
  return(dat)
}
#
# i <- 9
# xx <- getdistancesmat(allsamples[[i]]$z, 10, 300, seedit= 10101, tau = tuned$tau[i], gamma2 = tuned$gamma2[i])
# allmeans <- matrix(nrow = 300, ncol = max(xx$iteration))
# for(j in 1:max(xx$dyad)){
#   print(j)
#   yy <- subset(xx, dyad == j)$distances
#   allmeans[j,] <- cumsum(yy)/(1:length(yy))
# }
#
# plot(allmeans[1,])
#
# save(allsamples, file = "allsamples.Rdata")
