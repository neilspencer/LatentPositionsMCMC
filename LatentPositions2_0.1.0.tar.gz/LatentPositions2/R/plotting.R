#library(ggplot)
#library(RColorBrewer)

# plotAZ <- function(A, ztrue, edgecurve = 0, nodecolor = c("#00C7FC"), nodesize = 3, blank = T, edgespresent = T, idcolors = F, edgecolor = "black", edgesize = 0.5){
#
#   dfnodes <- data.frame(x = ztrue[,1], y = ztrue[,2], ids = as.factor(1:nrow(ztrue)))
#   empt <- rep(NA, sum(A))
#   dfedges <- data.frame(xstart = empt, xend = empt, ystart = empt, yend = empt)
#   edgelist <- data.frame(v1 = c(), v2 = c())
#   for(i in 1:nrow(A)){
#     edges <- (1:nrow(A))[A[i,] == 1]
#     if(length(edges) > 0){
#       nex <- cbind(v1 = i, v2 = edges)
#       edgelist <- rbind(edgelist, nex)
#     }
#   }
#
#
#   for(i in 1:length(empt)){
#     dfedges[i,] <- c(ztrue[edgelist[i,1], 1], ztrue[edgelist[i,2], 1], ztrue[edgelist[i,1], 2], ztrue[edgelist[i,2], 2])
#   }
#   dfedges <- subset(dfedges, yend > ystart)
#
#   p <- ggplot(dfnodes, aes(x = x, y = y))
#   if(edgespresent == T){
#     p <- p + geom_curve(data = dfedges, aes(x = xstart, y = ystart, xend = xend, yend = yend), curvature = edgecurve, color = edgecolor, size = edgesize)
#   }
#   if(idcolors == F){
#     p <- p +  geom_point(shape = 21, colour = "black", fill = nodecolor, size = nodesize, stroke = nodesize/5.5) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
#   }
#   else{
#     aaa <- brewer.pal(nrow(A),"Spectral")
#     names(aaa) <- as.factor(1:nrow(A))
#     p <- p +  geom_point(aes(fill = ids) , shape = 21, colour = "black", size = nodesize, stroke = nodesize/5.5) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
#     p <- p +  scale_fill_manual(values= aaa)
#   }
#  if(blank){
#     p <- p + theme(axis.line=element_blank(),axis.text.x=element_blank(),
#                      axis.text.y=element_blank(),axis.ticks=element_blank(),
#                      axis.title.x=element_blank(),
#                      axis.title.y=element_blank(),legend.position="none",
#                      panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
#                      panel.grid.minor=element_blank(),plot.background=element_blank())
#
#  }else{
#    p <- p + theme_bw() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) + theme(legend.position="none")
#  }
#   return(p)
# }
