# # This code is for various types of fitting

posterior_inference_stan <- function(A, Alabels, Omega, beta1, beta2, nruns, sigparam1 = 1, sigparam2 = 1, d = 2, sampletau = TRUE, tau = NA, samplesigma2inv = TRUE, sigma2inv = NA){
  # create all dyads matrix
  alldyads <- matrix(nrow = sum(Alabels >= 0)/2, ncol = 3)
  k <- 1
  for(i in 1:nrow(Alabels)){
    for(j in i:nrow(Alabels)){
      if(Alabels[i,j] >= 0){
        alldyads[k,] <- c(i, j, Alabels[i,j] + 1)
        k <- k + 1
      }
    }
  }

  if(samplesigma2inv == FALSE){
    if(sampletau == FALSE){
      dat <- list(nnodes = nrow(A), A = A, nalldyads = nrow(alldyads), alldyads = alldyads, d = d, ntaus = length(tau), Omegainv = solve(Omega), sigma2inv = sigma2inv, tau = tau)
      fit <-    rstan::stan(
        data = dat, iter = 2 * nruns, chains = 1, control = list(adapt_delta = 0.8),
        model_code = "data {
        int<lower= 3> nnodes; // number of nodes
        int<lower = 1> ntaus;
        int nalldyads;
        int alldyads[nalldyads, 3];
        int<lower = 0, upper = 1> A[nnodes, nnodes]; //adjacency matrix
        int<lower = 1> d; // dimension of the latent space
        matrix[nnodes, nnodes] Omegainv;
        real<lower = 0> sigma2inv;
        real<lower = 0, upper = 1> tau[ntaus];
    }
        parameters {
        matrix[nnodes, d] x;
        }
        transformed parameters {
        real<lower = 0, upper = 1> probs[nalldyads];
        real squares[nnodes];
        matrix[nnodes, d] z;
        for(i in 1:nnodes){
        squares[i] = dot_product(x[i,], x[i,]);
        }
        for(i in 1:nalldyads){
        probs[i] = tau[alldyads[i,3]] * exp(- 0.5/sigma2inv *(squares[alldyads[i,1]] + squares[alldyads[i,2]] - 2 * dot_product(x[alldyads[i,1],], x[alldyads[i,2], ])));
        }
        z = sqrt(1/sigma2inv) * x;

        }
        model {
        for(i in 1:nalldyads){
        A[alldyads[i,1], alldyads[i,2]] ~ bernoulli(probs[i]);
        }
        for(i in 1:d){
        x[,i] ~ multi_normal(rep_vector(0, nnodes), Omegainv);
        }
        }")
      la <- rstan::extract(fit, permuted = TRUE)
      zs <- aperm(la$z, c(2,3,1))
      logliks <- la$lp__
      taus <- matrix(tau, nrow = length(la$lp__), ncol = 2, byrow = T)
      sigma2invs <- rep(sigma2inv, length(la$lp__))
      tunetime <- as.numeric(rstan::get_elapsed_time(fit)[1])
      runtime <- as.numeric(rstan::get_elapsed_time(fit)[2])
      epsilon <- rstan::get_sampler_params(fit, inc_warmup = FALSE)[[1]][1,2]
      return(list(zs = zs, taus = taus, sigma2invs = sigma2invs, logliks = logliks, runtime = runtime,tunetime = tunetime, epsilon = epsilon))
  }else{
    dat <- list(nnodes = nrow(A), A = A, nalldyads = nrow(alldyads), alldyads = alldyads, d = d, ntaus = length(beta1), Omegainv = solve(Omega), beta1 = as.array(beta1), beta2 = as.array(beta2), sigma2inv = sigma2inv)
    fit <- rstan::stan(
      data = dat, iter = 2 * nruns, chains = 1, control = list(adapt_delta = 0.8),
      model_code = "/// this tends to be a faster parametrization than newstan2
      data {
      int<lower= 3> nnodes; // number of nodes
      int<lower = 1> ntaus;
      int nalldyads;
      int alldyads[nalldyads, 3];
      int<lower = 0, upper = 1> A[nnodes, nnodes]; //adjacency matrix
      int<lower = 1> d; // dimension of the latent space
      matrix[nnodes, nnodes] Omegainv;
      real<lower = 0> beta1[ntaus];
      real<lower = 0> beta2[ntaus];
      real<lower = 0> sigma2inv;
      }
      parameters {
      matrix[nnodes, d] x;
      real<lower = 0, upper = 1> tau[ntaus];
      }
      transformed parameters {
      real<lower = 0, upper = 1> probs[nalldyads];
      real squares[nnodes];
      matrix[nnodes, d] z;
      for(i in 1:nnodes){
      squares[i] = dot_product(x[i,], x[i,]);
      }
      for(i in 1:nalldyads){
      probs[i] = tau[alldyads[i,3]] * exp(- 0.5/sigma2inv *(squares[alldyads[i,1]] + squares[alldyads[i,2]] - 2 * dot_product(x[alldyads[i,1],], x[alldyads[i,2], ])));
      }
      z = sqrt(1/sigma2inv) * x;

      }
      model {
      for(i in 1:nalldyads){
      A[alldyads[i,1], alldyads[i,2]] ~ bernoulli(probs[i]);
      }
      tau ~ beta(beta1, beta2);
      for(i in 1:d){
      x[,i] ~ multi_normal(rep_vector(0, nnodes), Omegainv);
      }
      }
      ")
    la <- rstan::extract(fit, permuted = TRUE)
    zs <- aperm(la$z, c(2,3,1))
    logliks <- la$lp__
    taus <- la$tau
    sigma2invs <- rep(sigma2inv, length(la$lp__))
    runtime <- as.numeric(rstan::get_elapsed_time(fit)[2])
    tunetime <- as.numeric(rstan::get_elapsed_time(fit)[1])
    epsilon <- rstan::get_sampler_params(fit, inc_warmup = FALSE)[[1]][1,2]
    return(list(zs = zs, taus = taus, sigma2invs = sigma2invs, logliks = logliks, runtime = runtime,tunetime = tunetime, epsilon = epsilon))
  }

    }
  if(sampletau == FALSE){
    dat <- list(nnodes = nrow(A), A = A, nalldyads = nrow(alldyads), alldyads = alldyads, d = d, ntaus = length(tau), Omegainv = solve(Omega), sigparam1 = sigparam1, sigparam2 = sigparam2, tau = tau)
    fit <-    rstan::stan(
      data = dat, iter = 2 * nruns, chains = 1, control = list(adapt_delta = 0.8),
      model_code = "data {
      int<lower= 3> nnodes; // number of nodes
      int<lower = 1> ntaus;
      int nalldyads;
      int alldyads[nalldyads, 3];
      int<lower = 0, upper = 1> A[nnodes, nnodes]; //adjacency matrix
      int<lower = 1> d; // dimension of the latent space
      matrix[nnodes, nnodes] Omegainv;
      real<lower = 0> sigparam1;
      real<lower = 0> sigparam2;
      real<lower = 0, upper = 1> tau[ntaus];
  }
      parameters {
      matrix[nnodes, d] x;
      real<lower = 0> sigma2inv;
      }
      transformed parameters {
      real<lower = 0, upper = 1> probs[nalldyads];
      real squares[nnodes];
      matrix[nnodes, d] z;
      for(i in 1:nnodes){
      squares[i] = dot_product(x[i,], x[i,]);
      }
      for(i in 1:nalldyads){
      probs[i] = tau[alldyads[i,3]] * exp(- 0.5/sigma2inv *(squares[alldyads[i,1]] + squares[alldyads[i,2]] - 2 * dot_product(x[alldyads[i,1],], x[alldyads[i,2], ])));
      }
      z = sqrt(1/sigma2inv) * x;

      }
      model {
      for(i in 1:nalldyads){
      A[alldyads[i,1], alldyads[i,2]] ~ bernoulli(probs[i]);
      }
      sigma2inv ~ gamma(sigparam1, sigparam2); //
      for(i in 1:d){
      x[,i] ~ multi_normal(rep_vector(0, nnodes), Omegainv);
      }
      }")

    la <- rstan::extract(fit, permuted = TRUE)
    zs <- aperm(la$z, c(2,3,1))
    taus <- matrix(tau, nrow = length(la$lp__), ncol = 2, byrow = T)
    sigma2invs <- la$sigma2inv
    logliks <- la$lp__
    tunetime <- as.numeric(rstan::get_elapsed_time(fit)[1])
    runtime <- as.numeric(rstan::get_elapsed_time(fit)[2])
    epsilon <- rstan::get_sampler_params(fit, inc_warmup = FALSE)[[1]][1,2]
    return(list(zs = zs, taus = taus, sigma2invs = sigma2invs, logliks = logliks, runtime = runtime,tunetime = tunetime, epsilon = epsilon))
    }
  dat <- list(nnodes = nrow(A), A = A, nalldyads = nrow(alldyads), alldyads = alldyads, d = d, ntaus = length(beta1), Omegainv = solve(Omega), sigparam1 = sigparam1, sigparam2 = sigparam2, beta1 = as.array(beta1), beta2 = as.array(beta2))
  fit <-    rstan::stan(
    data = dat, iter = 2 * nruns, chains = 1, control = list(adapt_delta = 0.8),
    model_code = "data {
    int<lower= 3> nnodes; // number of nodes
    int<lower = 1> ntaus;
    int nalldyads;
    int alldyads[nalldyads, 3];
    int<lower = 0, upper = 1> A[nnodes, nnodes]; //adjacency matrix
    int<lower = 1> d; // dimension of the latent space
    matrix[nnodes, nnodes] Omegainv;
    real<lower = 0> sigparam1;
    real<lower = 0> sigparam2;
    real<lower = 0> beta1[ntaus];
    real<lower = 0> beta2[ntaus];
    }
    parameters {
    matrix[nnodes, d] x;
    real<lower = 0, upper = 1> tau[ntaus];
    real<lower = 0> sigma2inv;
    }
    transformed parameters {
    real<lower = 0, upper = 1> probs[nalldyads];
    real squares[nnodes];
    matrix[nnodes, d] z;
    for(i in 1:nnodes){
    squares[i] = dot_product(x[i,], x[i,]);
    }
    for(i in 1:nalldyads){
    probs[i] = tau[alldyads[i,3]] * exp(- 0.5/sigma2inv *(squares[alldyads[i,1]] + squares[alldyads[i,2]] - 2 * dot_product(x[alldyads[i,1],], x[alldyads[i,2], ])));
    }
    z = sqrt(1/sigma2inv) * x;

    }
    model {
    for(i in 1:nalldyads){
    A[alldyads[i,1], alldyads[i,2]] ~ bernoulli(probs[i]);
    }
    tau ~ beta(beta1, beta2);
    sigma2inv ~ gamma(sigparam1, sigparam2);
    for(i in 1:d){
    x[,i] ~ multi_normal(rep_vector(0, nnodes), Omegainv);
    }
    }")

  la <- rstan::extract(fit, permuted = TRUE)
  z <- aperm(la$z, c(2,3,1))
  sigma2inv <- la$sigma2inv
  logdensity <- la$lp__
  tau <- la$tau
  tunetime <- as.numeric(rstan::get_elapsed_time(fit)[1])
  runtime <- as.numeric(rstan::get_elapsed_time(fit)[2])
  epsilon <- rstan::get_sampler_params(fit, inc_warmup = FALSE)[[1]][1,2]
  return(list(z = z, tau = t(tau), sigma2inv = sigma2inv, logdensity = logdensity, runtime = runtime, tunetime = tunetime, epsilon = epsilon))
  }
