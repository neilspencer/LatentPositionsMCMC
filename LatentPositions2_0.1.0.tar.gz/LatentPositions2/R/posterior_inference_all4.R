posterior_inference <- function(A, Alabels, nruns, priorprecision = diag(nrow(A)), d = 2, method = "split HMC + firefly", sample_tau = TRUE, sample_sigma2inv = TRUE, z_init = "MLE", tau_init = rep(0.5, 1 + max(Alabels)), sigma2inv_init = 1, beta1 = rep(1, 1 + max(Alabels)), beta2 = rep(1, 1 + max(Alabels)), sigparam1 = 1, sigparam2 = 1, eps = 1/sqrt(nrow(A)), L = ceiling(2/eps), taurwsd = 0.05, zrwsd = 0.1 * 1/mean(diag(priorprecision)), tuneparams = TRUE, nruns_tuning = 300, thetas_init = NA){
  if((sample_tau == TRUE) & (sample_sigma2inv == TRUE)){
    fit <- posterior_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, beta1 = beta1, beta2 = beta2, sigparam1 = sigparam1, sigparam2 = sigparam2, d = d, z_init = z_init, tau_init = tau_init, sigma2inv_init = sigma2inv_init, eps = eps, L = L, taurwsd = taurwsd, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
  }
  if((sample_tau == FALSE) & (sample_sigma2inv == TRUE)){
    fit <- fixedtau_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, sigparam1 = sigparam1, sigparam2 = sigparam2, d = d, z_init = z_init, tau = tau_init, sigma2inv_init = sigma2inv_init, eps = eps, L = L, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    fit$tau <- matrix(tau_init, nrow = length(tau_init), ncol = nruns)
  }
  if((sample_tau == FALSE) & (sample_sigma2inv == FALSE)){
    fit <- fixedsigma2invtau_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, d = d, z_init = z_init, tau = tau_init, sigma2inv = sigma2inv_init, eps = eps, L = L, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    fit$sigma2inv <- rep(sigma2inv_init, nruns)
    fit$tau <- matrix(tau_init, nrow = length(tau_init), ncol = nruns)
  }
  if((sample_tau == TRUE) & (sample_sigma2inv == FALSE)){
    fit <- fixedsigma2inv_inference_all(A, Alabels, nruns, priorprecision = priorprecision, method = method, beta1 = beta1, beta2 = beta2, d = d, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, eps = eps, L = L, taurwsd = taurwsd, zrwsd = zrwsd, tuneparams = tuneparams, nruns_samp = nruns_tuning, thetas_init)
    fit$sigma2inv <- rep(sigma2inv_init, nruns)
  }
  fit$method <- method
  fit$A <- A
  fit$Alabels <- Alabels
  return(fit)
}

experimental_run <- function(Alabels, tau, sigma2inv, prior, method, nruns, sample_tau, sample_sigma2inv, graphseed = 1, mcmcseed = 1, nruns_tuning = 300, eps = 1/sqrt(nrow(Alabels)), L = ceiling(2/eps), taurwsd = 0.05, zrwsd =  0.1/mean(diag(prior))){
  set.seed(graphseed)
  creation <- createA(Alabels, tau, prior, sigma2inv, d = 2)
  A <- creation$A
  set.seed(mcmcseed)
  fit <- posterior_inference(A, Alabels, nruns, priorprecision = prior, method = method, sample_tau = sample_tau, sample_sigma2inv = sample_sigma2inv, nruns_tuning = nruns_tuning, eps = eps, taurwsd = taurwsd, zrwsd = zrwsd, tau_init = tau, sigma2inv_init = sigma2inv)
  return(fit)
}

process_fitlist_ess <- function(fits, missingdyads, burnin = 10){
  nmethods <- length(fits)
  dat <- data.frame(method = rep(NA, nmethods), time = rep(NA, nmethods), time_tune = rep(NA, nmethods), eps = rep(NA, nmethods), acceptrate= rep(NA, nmethods), ess_prob = rep(NA, nmethods), ess_logprob = rep(NA, nmethods))
  for(i in (1:nmethods)){
    dat$method[i] = as.character(fits[[i]]$method)
    dat$time[i] <- fits[[i]]$time
    dat$time_tune[i] <- fits[[i]]$runtime_tune
    if(is.na(fits[[i]]$params[1])){
        dat$eps[i] <- NA
    }
   else if(is.null((fits[[i]]$params)$eps)){
      dat$eps[i] <- NA
    }else{
      dat$eps[i] <- (fits[[i]]$params)$eps
    }
    dat$acceptrate[i] <- mean(fits[[i]]$z[1,1,-1] != fits[[i]]$z[1,1,-length(fits[[i]]$z[1,1,])])
    dists <- t(getdistances(missingdyads[,1], missingdyads[,2], fits[[i]]$z, dim(fits[[i]]$z)[3], nrow(missingdyads), d = 2))
    logprobs <- -dists/2
    for(j in 1:nrow(missingdyads)){
      logprobs[,j] <- logprobs[,j]  + log(fits[[i]]$tau[missingdyads[j,3] + 1,])
    }
    logprobsall <- rowSums(logprobs)
    probsall <- exp(logprobsall)
    dat$ess_prob[i] <- effectiveSize(probsall[-(1:burnin)])
    dat$ess_logprob[i] <- effectiveSize(logprobsall[-(1:burnin)])
  }
  return(dat)
}

fit_trace <- function(fit, missingdyads){
  dists <- t(getdistances(missingdyads[,1], missingdyads[,2], fit$z, dim(fit$z)[3], nrow(missingdyads), d = 2))
  logprobs <- -dists/2
  for(j in 1:nrow(missingdyads)){
    logprobs[,j] <- logprobs[,j]  + log(fit$tau[missingdyads[j,3] + 1,])
  }
  sigma2invs <- fit$sigma2inv
  taus <- fit$tau
  df <- data.frame(iteration = 1:length(sigma2invs), sigma2invs = sigma2invs)
  for(i in 1:nrow(taus)){
    stringname <-  paste("tau", i, sep = "")
    df <- cbind(df, taus[i,])
    names(df)[length(names(df))] <- stringname
  }
  for(i in 1:nrow(missingdyads)){
    stringname <-  paste("logprob", i, sep = "")
    df <- cbind(df, logprobs[,i])
    names(df)[length(names(df))] <- stringname
  }
  return(df)
}


process_fitlist_essmin <- function(fits, missingdyads, burnin = 10){
  nmethods <- length(fits)
  dat <- data.frame(method = rep(NA, nmethods), time = rep(NA, nmethods), time_tune = rep(NA, nmethods), eps = rep(NA, nmethods), acceptrate= rep(NA, nmethods), ess_logprob = rep(NA, nmethods))
  for(i in (1:nmethods)){
    dat$method[i] = as.character(fits[[i]]$method)
    dat$time[i] <- fits[[i]]$time
    dat$time_tune[i] <- fits[[i]]$runtime_tune
    if(is.na(fits[[i]]$params[1])){
      dat$eps[i] <- NA
    }else if(is.null((fits[[i]]$params)$eps)){
      dat$eps[i] <- NA
    }else{
      dat$eps[i] <- (fits[[i]]$params)$eps
    }
    dat$acceptrate[i] <- mean(fits[[i]]$z[1,1,-1] != fits[[i]]$z[1,1,-length(fits[[i]]$z[1,1,])])
    xxx <- fit_trace(fits[[i]], missingdyads)
    dat$ess_logprob[i] <- min(effectiveSize(xxx[, 4:ncol(xxx)]))
  }
  return(dat)
}

