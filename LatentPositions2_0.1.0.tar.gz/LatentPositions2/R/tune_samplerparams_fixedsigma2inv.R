
tuningfixedsigma2invepsilon <- function(method, A, Alabels, prior, tau_init, sigma2inv_init, z_init, thetas_init, nruns_samp, beta1, beta2, taurwsd = 0.1, upper = 2, lower = 0, targetrange = c(0.8, 0.85), d = 2){
  epsmethods <- c("split HMC", "split HMC + firefly", "leapfrog HMC", "leapfrog HMC + firefly", "nuts", "nuts + firefly")
  if(!(method %in% epsmethods)){
    strr <- paste("Method must be one of ", epsmethods[1])
    for(i in 2:length(epsmethods)){
      strr <- paste(strr, epsmethods[i], sep = ", ")
    }
    stop(strr)
  }

  return(tuneepshelp2(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init, thetas_init, nruns_samp, beta1, beta2, taurwsd = taurwsd, upper = upper, lower = lower, targetrange = targetrange))
}

tuningfixedsigma2invzrw <- function(method, A, Alabels, prior, tau_init, sigma2inv_init, z_init, thetas_init, nruns_samp, beta1, beta2, taurwsd = 0.1, upper = 10, lower = 0, targetrange = c(0.2, 0.3), d = 2){
  metmethods <- c("Metropolis within Gibbs", "Metropolis within Gibbs + firefly")
  if(!(method %in% metmethods)){
    strr <- paste("Method must be one of ", metmethods[1])
    for(i in 2:length(metmethods)){
      strr <- paste(strr, metmethods[i], sep = ", ")
    }
    stop(strr)
  }

  return(tunezrwhelp2(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init, thetas_init, nruns_samp, beta1, beta2, taurwsd = taurwsd, upper = upper, lower = lower, targetrange = targetrange))
}

tuningfixedsigma2invtaurw <- function(method, A, Alabels, prior, tau_init, sigma2inv_init, z_init, nruns_samp, beta1, beta2, upper = 10, lower = 0, targetrange = c(0.2, 0.3), d = 2, L = 10, eps = 0.2, zrwsd = 0.05){
  metmethods <- c("split HMC", "leapfrog HMC", "elliptical slice", "Metropolis within Gibbs", "nuts", "elliptical slice within Gibbs")
  if(!(method %in% metmethods)){
    strr <- paste("Method must be one of ", metmethods[1])
    for(i in 2:length(metmethods)){
      strr <- paste(strr, metmethods[i], sep = ", ")
    }
    stop(strr)
  }

  return(tunetaurwhelp2(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init, nruns_samp, beta1, beta2, upper = upper, lower = lower, targetrange = targetrange, L = L, eps = eps, zrwsd = zrwsd))
}

# helper function inside of tuneiteps2
tuneepshelp2 <- function(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init,thetas_init, nruns_samp, beta1, beta2, taurwsd = 0.1, upper = 2, lower = 0, targetrange = c(0.8, 0.85)){
  upperver <- F
  while(upperver == F){
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, eps = upper, L = ceiling(2/upper), taurwsd = taurwsd, thetas_init = thetas_init)
    rat <- mean(yy$z[1,1,-1] != yy$z[1,1,-nruns_samp])
    if(rat > targetrange[2]){
      upper = 2 * upper
    }else{
      if(rat > targetrange[1]){
        return(upper)
      }else{
        upperver <- T
      }
    }
  }
  for(i in 1:100){
    newp <- mean(c(upper, lower))
    print(newp)
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, eps = newp, L = ceiling(2/newp), taurwsd = taurwsd, thetas_init = thetas_init)
    rat <- mean(yy$z[1,1,-1] != yy$z[1,1,-nruns_samp])
    print(rat)
    if((rat >= targetrange[1]) && (rat <= targetrange[2])){
      return(newp)
    }
    if(rat < targetrange[1]){
      upper <- newp
    }else{
      if(rat > targetrange[2]){
        lower <- newp
      }
    }
  }
  return(NA)
}


# helper function inside of tuneiteps2
tunezrwhelp2 <- function(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init, thetas_init, nruns_samp, beta1, beta2, taurwsd = 0.1, upper = 10, lower = 0, targetrange = c(0.2, 0.3)){
  upperver <- F
  while(upperver == F){
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, zrwsd = upper, taurwsd = taurwsd, thetas_init = thetas_init)
    rat <- mean(yy$z[,,-1] != yy$z[,,-nruns_samp])
    if(rat > targetrange[2]){
      upper = 2 * upper
    }else{
      if(rat > targetrange[1]){
        return(upper)
      }else{
        upperver <- T
      }
    }
  }
  for(i in 1:100){
    newp <- mean(c(upper, lower))
    print(newp)
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, zrwsd = newp, taurwsd = taurwsd, thetas_init = thetas_init)
    rat <- mean(yy$z[,,-1] != yy$z[,,-nruns_samp])
    print(rat)
    if((rat >= targetrange[1]) && (rat <= targetrange[2])){
      return(newp)
    }
    if(rat < targetrange[1]){
      upper <- newp
    }else{
      if(rat > targetrange[2]){
        lower <- newp
      }
    }
  }
  return(NA)
}


# helper function inside of tuneiteps2
tunetaurwhelp2 <- function(method, A, Alabels, prior, z_init, tau_init, sigma2inv_init, nruns_samp, beta1, beta2, upper = 10, lower = 0, targetrange = c(0.25, 0.4), L = 10, eps = 0.2, zrwsd = 0.2){
  upperver <- F
  while(upperver == F){
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, zrwsd = zrwsd, L = L, eps = eps, taurwsd = upper)
    rat <- mean(yy$tau[,-1] != yy$tau[,-nruns_samp])
    if(rat > targetrange[2]){
      upper = 2 * upper
    }else{
      if(rat > targetrange[1]){
        return(upper)
      }else{
        upperver <- T
      }
    }
  }
  for(i in 1:100){
    newp <- mean(c(upper, lower))
    print(newp)
    yy <- fixedsigma2inv_inference_all(A, Alabels, nruns_samp, prior, method, beta1 = beta1, beta2 = beta2, z_init = z_init, tau_init = tau_init, sigma2inv = sigma2inv_init, zrwsd = zrwsd, L = L, eps = eps, taurwsd = newp)
    rat <- mean(yy$tau[,-1] != yy$tau[,-nruns_samp])
    print(rat)
    if((rat >= targetrange[1]) && (rat <= targetrange[2])){
      return(newp)
    }
    if(rat < targetrange[1]){
      upper <- newp
    }else{
      if(rat > targetrange[2]){
        lower <- newp
      }
    }
  }
  return(NA)
}

