#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
#include "zupdates.h"
#include "helperobjects.h"
#include "nuts.h"

using namespace Rcpp;

// [[Rcpp::export]]
List fixedsigma2inv_inference_splitHMC(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                  arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                                  int nruns, arma::vec beta1, arma::vec beta2,
                                  double eps = 0.1, int L = 20, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmat_inv = inv(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat); // find initial density.
    List updated = zupdate_splitHMC(z, L, eps, dyads2, onestau, gaussmat, gaussmat_inv, pdf);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_splitHMCchol(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                      arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                                      int nruns, arma::vec beta1, arma::vec beta2,
                                      double eps = 0.1, int L = 20, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A

  // update the Laplacian and inverse using new precision (sigma2inv)
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat R = arma::chol(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat); // find initial density.
    List updated = zupdate_splitHMCprechol(z, L, eps, dyads2, onestau, gaussmat, pdf, R);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}


// [[Rcpp::export]]
List fixedsigma2inv_inference_splitHMCcholnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                          arma::vec tau_init, double sigma2inv,
                                          int nruns, arma::vec beta1, arma::vec beta2,
                                          double eps = 0.1, int L = 20, double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat R = arma::chol(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }

    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat); // find initial density.
    List updated = zupdate_splitHMCprechol(z, L, eps, dyads, tau, gaussmat, pdf, R);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_splitHMCnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                      arma::vec tau_init, double sigma2inv,
                                      int nruns, arma::vec beta1, arma::vec beta2,
                                      double eps = 0.1, int L = 20, double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmat_inv = inv(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }

    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat); // find initial density.
    List updated = zupdate_splitHMC(z, L, eps, dyads, tau, gaussmat, gaussmat_inv, pdf);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_HMC(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                             arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                             int nruns, arma::vec beta1, arma::vec beta2,
                             double eps = 0.1, int L = 20, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A

  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmat_inv = inv(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat); // find initial density.
    List updated = zupdate_HMC(z, L, eps, dyads2, onestau, gaussmat, gaussmat_inv, pdf);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_HMCnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                 arma::vec tau_init, double sigma2inv,
                                 int nruns, arma::vec beta1, arma::vec beta2,
                                 double eps = 0.1, int L = 20, double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::mat z = z_init; // initialize the z matrix
  arma::vec tau = tau_init; // initialize tau

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmat_inv = inv(gaussmat);


  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // update the Laplacian and inverse using new precision (sigma2inv)


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }

    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat); // find initial density.
    List updated = zupdate_HMC(z, L, eps, dyads, tau, gaussmat, gaussmat_inv, pdf);
    arma::mat znew = updated[0];
    zs.slice(run) = znew;
    z = znew;
    pdf = updated[1];

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_slice(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                               arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                               int nruns, arma::vec beta1, arma::vec beta2, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;


  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    z = zupdate_ellipticalslice(z, dyads2, onestau, gaussmat);
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat);
    zs.slice(run) = z;

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_slicenoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                   arma::vec tau_init, double sigma2inv,
                                   int nruns, arma::vec beta1, arma::vec beta2,
                                  double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }
    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    z = zupdate_ellipticalslice(z, dyads, tau, gaussmat);
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat);
    zs.slice(run) = z;
    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}


// [[Rcpp::export]]
List fixedsigma2inv_inference_mcmc(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                              arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                              int nruns, double rwsd, arma::vec beta1, arma::vec beta2, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  // update the Laplacian and inverse using new precision (sigma2inv)
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;

  // create stuff needed to work with mcmc
  List mcmcstuff = getGibbsObjects(A, Alabels, gaussmat);
  arma::mat connecteds = mcmcstuff[0];
  arma::mat disconnecteds = mcmcstuff[1];
  arma::vec connectednums = mcmcstuff[2];
  arma::vec disconnectednums = mcmcstuff[3];
  arma::mat disconnectedthetaindices = createdisconnectedindices(disconnecteds, disconnectednums, dyads);


  gaussmat = Laplacian + sigma2inv * priorprecision;

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    List draw = zupdate_metGibbs(z, rwsd, connecteds, disconnecteds, connectednums, disconnectednums, gaussmat, disconnectedthetaindices, thetas);
    arma::mat znew = draw[0];
    z = znew;
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat);
    zs.slice(run) = z;

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_mcmcnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                  arma::vec tau_init, double sigma2inv,
                                  int nruns, double rwsd, arma::vec beta1, arma::vec beta2,
                                  double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  // update the Laplacian and inverse using new precision (sigma2inv)
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;

  // create stuff needed to work with mcmc
  List mcmcstuff = getGibbsObjects(A, Alabels, gaussmat);
  arma::mat connecteds = mcmcstuff[0];
  arma::mat disconnecteds = mcmcstuff[1];
  arma::vec connectednums = mcmcstuff[2];
  arma::vec disconnectednums = mcmcstuff[3];

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }
    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    List draw = zupdate_metGibbsnoFF(z, rwsd, connecteds, disconnecteds, connectednums, disconnectednums, gaussmat, tau, Alabels);
    arma::mat znew = draw[0];
    z = znew;
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat);
    zs.slice(run) = z;

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}


// [[Rcpp::export]]
List fixedsigma2inv_inference_nuts(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                              arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                              int nruns, arma::vec beta1, arma::vec beta2,
                              double eps = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  // update the Laplacian and inverse using new precision (sigma2inv)
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat R = arma::chol(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo

    arma::mat znew = nutsR(z, eps, onestau, gaussmat, dyads2, 1000, R);
    zs.slice(run) = znew;
    z = znew;
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat); // find initial density.

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}


// [[Rcpp::export]]
List fixedsigma2inv_inference_nutsnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                  arma::vec tau_init, double sigma2inv,
                                  int nruns, arma::vec beta1, arma::vec beta2,
                                  double eps = 0.1, double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat R = arma::chol(gaussmat);

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }

    taus.col(run) = tau; // store the taus

    // update latent positions using split Hamiltonian Monte Carlo
    arma::mat znew = nutsR(z, eps, tau, gaussmat, dyads, 1000, R);
    zs.slice(run) = znew;
    z = znew;
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat); // find initial density.

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_sliceGibbs(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                    arma::vec tau_init, double sigma2inv, arma::vec thetas_init,
                                    int nruns, arma::vec beta1, arma::vec beta2, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads

  arma::vec thetas = thetas_init;

  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::vec onestau = ones(ntaus); // a vector of ones to acts as new tau after theta
  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmatinv = inv(gaussmat);
  arma::mat premeans(n, n);
  arma::vec vars(n);
  arma::uvec ops(n-1);

  for(int i = 0; i < n - 1; ++i){
    ops[i] = i + 1;
  }
  arma::uvec theone = zeros<uvec>(1);
  premeans = premeans * 0;
  vars = vars * 0;
  for(int i = 0; i < n; ++i){
    arma::mat Sig22 = gaussmatinv.submat(ops, ops);
    arma::mat Sig22inv = inv(Sig22);
    arma::mat Sig12 = gaussmatinv.submat(i + theone, ops);
    arma::mat Sig21 = gaussmatinv.submat(ops, i + theone);
    arma::mat needed = Sig12 * Sig22inv * Sig21;
    vars(i) = gaussmatinv(i,i) - needed(0,0);
    arma::mat premeani = Sig12 * Sig22inv;
    for(int j = 0; j < n - 1; ++j){
      premeans(i, ops[j]) = premeani(0, j);
    }
    premeans(i, i) = 0;
    ops[i] = i;
  }

  // create stuff needed to work with mcmc
  List mcmcstuff = getGibbsObjects(A, Alabels, gaussmat);
  arma::mat disconnecteds = mcmcstuff[1];
  arma::vec disconnectednums = mcmcstuff[3];
  arma::mat disconnectedthetaindices = createdisconnectedindices(disconnecteds, disconnectednums, dyads);
  arma::mat priorconnecteds(n, n - 1, fill::ones);
  priorconnecteds = -1 * priorconnecteds;
  arma::vec priorconnectednums(n);
  for(int i = 0; i < n; ++i){
    int a1 = 0;
    for(int j = 0; j < n; ++j){
      if(priorprecision(i,j) != 0){
        if(i != j){
          priorconnecteds(i, a1) = j;
          a1++;
        }
      }
    }
    priorconnectednums[i] = a1;
  }

  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // Gibbs update the theta variables
    thetas = update_thetas_categorical(thetas, z, dyads, 1.0, tau);
    int nthetas1 = accu(thetas); // determine how many are one
    arma::mat dyads2(nthetas1, 3); // create a new dyads matrix indexing only those for which theta is 1
    int kk = 0;
    for(int jj = 0; jj < ndyads; ++jj){
      if(thetas(jj) == 1){
        dyads2(kk, 0) = dyads(jj, 0); // record node 1
        dyads2(kk, 1) = dyads(jj, 1); // record node 2
        dyads2(kk, 2) = dyads(jj, 2); // record category of dyad
        kk = kk + 1;
      }
    }

    // update latent positions using split Hamiltonian Monte Carlo
    z = zupdate_ellipticalsliceGibbs(z, sigma2inv, sigma2inv, premeans, vars, disconnecteds, disconnectednums, disconnectedthetaindices, thetas, priorconnecteds, priorconnectednums, priorprecision);
    double pdf = ld_all_categorical(z, dyads2, 1.0, onestau, gaussmat);
    zs.slice(run) = z;

    // Gibbs sample each tau variable
    arma::vec nthetas1cat(ntaus);
    arma::vec nthetas0cat(ntaus);
    for(int i = 0; i < ntaus; ++i){
      nthetas1cat[i] = accu(thetas.elem(dyadids[i]));
      nthetas0cat[i] = ndyadsincat[i] - nthetas1cat[i];
      nthetas1cat[i] = nthetas1cat[i] + nedges_categories[i];
      tau[i] = rbeta(beta1[i] + nthetas1cat[i], beta2[i] + nthetas0cat[i]);
    }
    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_theta(tau, nthetas0cat, nthetas1cat) + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities, _["thetas"] = thetas));
}

// [[Rcpp::export]]
List fixedsigma2inv_inference_sliceGibbsnoFF(arma::mat A, arma::mat Alabels, arma::mat priorprecision, arma::mat z_init,
                                        arma::vec tau_init, double sigma2inv,
                                        int nruns, arma::vec beta1, arma::vec beta2,
                                        double taurw = 0.1, int likelihood_thin = 100
){
  int ntaus = tau_init.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::vec tau = tau_init; // initialize tau
  arma::mat z = z_init; // initialize the z matrix

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  std::vector<arma::uvec> dyadids = ret[1]; // holds the indices of the non-edge dyads in each category
  arma::vec ndyadsincat = ret[2];  // holds the number of non-edge dyads in each category
  arma::vec nedges_categories = ret[3]; // holds the number of edges observed for each category
  int ndyads = dyads.n_rows; // the number of dyads
  std::vector<arma::mat> dyadsforcats;
  for(int i = 0; i <ntaus; ++i){
    dyadsforcats.push_back(dyads.rows(dyadids[i]));
  }


  // make containers for the output samples
  arma::cube zs(n, d, nruns); // the samples for z
  arma::mat taus(ntaus, nruns); // the samples for tau
  std::vector<double> logdensities; // the density of the draw

  arma::mat Laplacian = getLaplacian(A); // compute the Laplacian of A
  arma::mat premeans(n, n);
  arma::vec vars(n);
  arma::uvec ops(n-1);

  // create stuff needed to work with mcmc
  arma::mat gaussmat = Laplacian + sigma2inv * priorprecision;
  arma::mat gaussmatinv = inv(gaussmat);
  List mcmcstuff = getGibbsObjects(A, Alabels, gaussmat);
  arma::mat disconnecteds = mcmcstuff[1];
  arma::vec disconnectednums = mcmcstuff[3];
  arma::mat priorconnecteds(n, n - 1, fill::ones);
  priorconnecteds = -1 * priorconnecteds;
  arma::vec priorconnectednums(n);
  for(int i = 0; i < n; ++i){
    int a1 = 0;
    for(int j = 0; j < n; ++j){
      if(priorprecision(i,j) != 0){
        if(i != j){
          priorconnecteds(i, a1) = j;
          a1++;
        }
      }
    }
    priorconnectednums[i] = a1;
  }
  // so we do not need to make another function
  arma::mat disconnectedthetaindices = createdisconnectedindices(disconnecteds, disconnectednums, dyads);
  arma::vec thetas(ndyads, fill::ones);


  for(int i = 0; i < n - 1; ++i){
    ops[i] = i + 1;
  }
  arma::uvec theone = zeros<uvec>(1);
  premeans = premeans * 0;
  vars = vars * 0;
  for(int i = 0; i < n; ++i){
    arma::mat Sig22 = gaussmatinv.submat(ops, ops);
    arma::mat Sig22inv = inv(Sig22);
    arma::mat Sig12 = gaussmatinv.submat(i + theone, ops);
    arma::mat Sig21 = gaussmatinv.submat(ops, i + theone);
    arma::mat needed = Sig12 * Sig22inv * Sig21;
    vars(i) = gaussmatinv(i,i) - needed(0,0);
    arma::mat premeani = Sig12 * Sig22inv;
    for(int j = 0; j < n - 1; ++j){
      premeans(i, ops[j]) = premeani(0, j);
    }
    premeans(i, i) = 0;
    ops[i] = i;
  }


  // running the sampler
  for(int run = 0; run < nruns; ++run){


    // update latent positions using split Hamiltonian Monte Carlo
    z = zupdate_ellipticalsliceGibbsnoFF(z, sigma2inv, sigma2inv, premeans, vars, disconnecteds, disconnectednums, tau, priorconnecteds, priorconnectednums, priorprecision, Alabels);
    double pdf = ld_all_categorical(z, dyads, 1.0, tau, gaussmat);
    zs.slice(run) = z;

    // MH sample each tau variable
    for(int i = 0; i < ntaus; ++i){
      double taunew = tau[i] + (runif() - 0.5) * taurw;
      if(taunew >= 0){
        if(taunew <= 1){
          double logMH = ld_nogaussian(z, dyadsforcats[i], 1.0, taunew) + (log(taunew) - log(tau[i])) * (nedges_categories[i] + beta1[i] - 1) + (log(1.0 - taunew) - log(1.0 - tau[i])) * (beta2[i] - 1) - ld_nogaussian(z, dyadsforcats[i], 1.0, tau[i]);
          if(log(runif()) < logMH){
            tau[i] = taunew;
          }
        }
      }
    }

    taus.col(run) = tau; // store the taus

    if(run % likelihood_thin == 0){
      Rcpp::Rcout << run << std::endl;
      logdensities.push_back(pdf + ld_tau(tau, beta1, beta2));
    }
  }
  return(List::create(_["z"]= zs, _["tau"]= taus, _["logdensity"] = logdensities));
}



