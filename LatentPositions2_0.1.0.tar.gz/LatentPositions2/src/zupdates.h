#ifndef zupdates_h
#define zupdates_h
#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
using namespace Rcpp;
List zupdate_splitHMC(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, arma::mat gaussmat_inv, double pdf_old);
List zupdate_splitHMCchol(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, double pdf_old);
List zupdate_splitHMCprechol(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, double pdf_old, arma::mat R);
List zupdate_HMC(arma::mat z, int L, double eps, arma::mat dyads, arma::vec tau, arma::mat gaussmat, arma::mat gaussmat_inv, double pdf_old);
arma::mat zupdate_ellipticalslice(arma::mat z, arma::mat dyads, arma::vec tau, arma::mat gaussmat);
List zupdate_metGibbs(arma::mat z, double rwsd, arma::mat connecteds, arma::mat disconnecteds, arma::vec connectednums, arma::vec disconnectednums, arma::mat gaussmat, arma::mat disconnectedthetaindices, arma::vec theta);
List zupdate_metGibbsnoFF(arma::mat z, double rwsd, arma::mat connecteds, arma::mat disconnecteds, arma::vec connectednums, arma::vec disconnectednums, arma::mat gaussmat, arma::vec tau, arma::mat Alabels);
arma::mat zupdate_ellipticalsliceGibbs(arma::mat z, double sigma2inv, double sigma2inv_init, arma::mat premeans, arma::vec vars, arma::mat disconnecteds, arma::vec disconnectednums, arma::mat disconnectedthetaindices, arma::vec theta, arma::mat priorconnecteds, arma::vec priorconnectednums, arma::mat priorprecision);
arma::mat zupdate_ellipticalsliceGibbsnoFF(arma::mat z, double sigma2inv, double sigma2inv_init, arma::mat premeans, arma::vec vars, arma::mat disconnecteds, arma::vec disconnectednums, arma::vec tau, arma::mat priorconnecteds, arma::vec priorconnectednums, arma::mat priorprecision, arma::mat Alabels);
#endif
