#include "common.h"
#include <RcppArmadillo.h>
#include <algorithm>
using namespace Rcpp;
using namespace arma;


// compute X^{-1}y given cholesky factor R (X = R'R)
vec chol_solve(mat &R, vec &y) {
  return(solve(trimatu(R), solve(trimatl(R.t()), y)));
}

// compute X^{-1}y given cholesky factor R (X = R'R)
arma::mat chol_solve2(mat &R, arma::mat &y) {
  return(solve(trimatu(R), solve(trimatl(R.t()), y)));
}


mat arma_rbind_all(std::vector<vec> &rows) {
  int n = rows.size();
  int p = rows[0].size();
  mat out(p, n);
  for(int i=0; i<n; ++i) {
    out.col(i) = rows[i];
  }
  return(out.t());
}

imat arma_rbind_all(std::vector<ivec> &rows) {
  int n = rows.size();
  int p = rows[0].size();
  imat out(p, n);
  for(int i=0; i<n; ++i) {
    out.col(i) = rows[i];
  }
  return(out.t());
}
