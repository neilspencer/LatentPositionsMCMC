#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"

using namespace Rcpp;

// could be sped up by saving squares of positions

// need to fix descendants and ancestors of points.
// the targetted density
double ldrow_temporal(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat lineage, double gamma2, double tau, double sigma2, double delta2, double alpha){

  double square = dot(z.row(i), z.row(i));
  double res = 0;
  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    res += log(1.0 - tau * exp(-0.5/gamma2 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
  }
  //edge dyads
  for(int j = 0; j < connectednum; ++j){
    res -= 0.5/gamma2 * (square - 2.0 * dot(z.row(connecteds(i,j)), z.row(i)));
  }
  //incorporating parents
  if(lineage(i, 0) != -1){
    res -= 0.5/delta2 * (square - 2.0 * alpha * dot(z.row(lineage(i,0)), z.row(i)));
  }
  // or prior
  else{
    res -= 0.5/sigma2 * (square);
  }
  // // incorporating children
  if(lineage(i, 1) != -1){
    res -= 0.5/delta2 * (alpha * alpha * square - 2.0 * alpha * dot(z.row(lineage(i,1)), z.row(i)));
  }
  return(res);
}

double ldrow_temporal_firefly(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat lineage, double gamma2, double tau, double sigma2, double delta2, double alpha, arma::vec theta, arma::mat disconnectedthetaindices){

  double square = dot(z.row(i), z.row(i));
  double res = 0;
  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    if(theta(disconnectedthetaindices(i, j)) == 1){
      res += log(1.0 - exp(-0.5/gamma2 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
    }
  }
  //edge dyads
  for(int j = 0; j < connectednum; ++j){
    res -= 0.5/gamma2 * (square - 2.0 * dot(z.row(connecteds(i,j)), z.row(i)));
  }
  //incorporating parents
  if(lineage(i, 0) != -1){
    res -= 0.5/delta2 * (square - 2.0 * alpha * dot(z.row(lineage(i,0)), z.row(i)));
  }
  // or prior
  else{
    res -= 0.5/sigma2 * (square);
  }
  // // incorporating children
  if(lineage(i, 1) != -1){
    res -= 0.5/delta2 * (alpha * alpha * square - 2.0 * alpha * dot(z.row(lineage(i,1)), z.row(i)));
  }
  return(res);
}

double ldrow_logistic(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat lineage, double sigma2, double delta2, double alpha){

  double square = dot(z.row(i), z.row(i));
  double res = 0;
  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    res -= log(1.0 + exp(-sqrt(square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
  }
  //edge dyads
  for(int j = 0; j < connectednum; ++j){
    res -= log(1.0 + exp(sqrt(square + dot(z.row(connecteds(i,j)), z.row(connecteds(i,j))) - 2.0 * dot(z.row(connecteds(i,j)), z.row(i)))));
  }
  //incorporating parents
  if(lineage(i, 0) != -1){
    res -= 0.5/delta2 * (square - 2.0 * alpha * dot(z.row(lineage(i,0)), z.row(i)));
  }
  // or prior
  else{
    res -= 0.5/sigma2 * (square);
  }
  // // incorporating children
  if(lineage(i, 1) != -1){
    res -= 0.5/delta2 * (alpha * alpha * square - 2.0 * alpha * dot(z.row(lineage(i,1)), z.row(i)));
  }
  return(res);
}

// [[Rcpp::export]]
double ldzi_firefly(int i, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::mat gaussmat, arma::mat disconnectedthetaindices, arma::vec theta){
  double res = 0;
  double square = dot(z.row(i), z.row(i));
  for(int j =0; j < connectednum; ++j){
    res -= gaussmat(i, connecteds(i,j)) * dot(z.row(i), z.row(connecteds(i,j)));
  }
  res += 0.5 * gaussmat(i,i) * square;

  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    if(theta(disconnectedthetaindices(i, j)) == 1){
    res += log(1.0 - exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
    }
  }

  return(res);
}

double ldzi_nofirefly(int i, arma::mat Alabels, arma::mat z, arma::mat connecteds, int connectednum, arma::mat disconnecteds, int disconnectednum, arma::vec tau, arma::mat gaussmat){
  double res = 0;
  double square = dot(z.row(i), z.row(i));
  for(int j =0; j < connectednum; ++j){
    res -= gaussmat(i,connecteds(i,j)) * dot(z.row(i), z.row(connecteds(i,j)));
  }
  res += 0.5 * gaussmat(i,i) * square;

  //no edge dyads
  for(int j = 0; j < disconnectednum; ++j){
    res += log(1.0 - tau[Alabels(i, disconnecteds(i,j))] * exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
  }
  return(res);
}

