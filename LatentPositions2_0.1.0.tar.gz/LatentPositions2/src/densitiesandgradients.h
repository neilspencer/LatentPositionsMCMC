#ifndef densitiesandgradients_h
#define densitiesandgradients_h
#include <RcppArmadillo.h>
using namespace Rcpp;

double ld_nogaussian(arma::mat z, arma::mat dyads, double gamma2, double tau);
double ld_nogaussian_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau);
double ld_gaussian(arma::mat z, arma::mat gaussmat);
double ld_all(arma::mat z, arma::mat dyads, double gamma2, double tau, arma::mat gaussmat);
double ld_all_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau, arma::mat gaussmat);
arma::mat gradient_nogaussian(arma::mat z_, arma::mat dyads, double gamma2, double tau) ;
arma::mat gradient_nogaussian_categorical(arma::mat z_, arma::mat dyads, double gamma2, arma::vec tau) ;
arma::mat gradient_all(arma::mat z_, arma::mat dyads, double gamma2, double tau, arma::mat gaussmat) ;
arma::mat gradient_all_categorical(arma::mat z_, arma::mat dyads, double gamma2, arma::vec tau, arma::mat gaussmat) ;
arma::mat gradient_logistic(arma::mat z_, arma::mat A, arma::mat priormat);
double ld_logistic(arma::mat z, arma::mat A, arma::mat priormat);
double ld_tau(arma::vec tau, arma::vec beta1, arma::vec beta2);
double ld_sigma2inv(double sigma2inv, double param1, double param2);
arma::mat MLE_initialize2(arma::mat A, arma::mat Alabels, arma::mat prior, arma::mat z_init, arma::vec tau, double sigma2inv, double eps, int niterations);
double ld_theta(arma::vec tau, arma::vec nthetas0cat, arma::vec nthetas1cat);
#endif

