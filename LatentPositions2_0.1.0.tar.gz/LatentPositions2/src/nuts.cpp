#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
#include "common.h"

List buildtree(arma::mat z, arma::mat s, double logu, double v, double j, double eps, arma::mat R, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax){
  //Rcpp::Rcout << j << std::endl;
  int d = z.n_cols;
  if(j == 0){
    // single leapfrog step
    arma::mat znew = z;
    arma::mat grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
    double eps2 = v * eps;
    arma::mat snew = s - eps2/2.0 *  chol_solve2(R, grd);
    double sineps = sin(eps2);
    double coseps = cos(eps2);
    arma::mat a = snew;
    arma::mat b = znew;
    znew = a * sineps + b * coseps;
    snew = a * coseps - b * sineps;
    grd = gradient_nogaussian_categorical(znew, dyads, 1.0, tau);
    snew = snew - eps2/2 * chol_solve2(R, grd);

    // calculate the metropolis hastings ratio
    arma::mat mom_post(1,1);
    mom_post(0,0) = 0;
    for(int i = 0; i < d; ++i){
      mom_post = mom_post + ((snew.col(i)).t()) * gaussmat * (snew.col(i));
    }
    double logpdf =  ld_all_categorical(znew, dyads, 1.0, tau, gaussmat) - 0.5 * mom_post(0,0);
    double nprime = 0.0;
    double sprime = 0.0;
    if(logpdf >= logu - deltamax){
      sprime++;
      if(logpdf >= logu){
        nprime++;
      }
    }
    return(List::create(znew, snew, znew, snew, znew, nprime, sprime));
  }else{
    List tree = buildtree(z, s, logu, v, j - 1, eps, R, tau, gaussmat, dyads, deltamax);
    arma::mat zneg = tree[0];
    arma::mat sneg = tree[1];
    arma::mat zpos = tree[2];
    arma::mat spos = tree[3];
    arma::mat zprime = tree[4];
    double nprime = tree[5];
    double sprime = tree[6];
    arma::mat zprime2;
    double nprime2;
    double sprime2;
    if(sprime == 1){
      if(v == -1){
        tree = buildtree(zneg, sneg, logu, v, j - 1, eps, R, tau, gaussmat, dyads, deltamax);
        arma::mat tree0 = tree[0];
        zneg = tree0;
        arma::mat tree1 = tree[1];
        sneg = tree1;
        arma::mat tree4 = tree[4];
        zprime2 = tree4;
        double tree5 = tree[5];
        nprime2 = tree5;
        double tree6 = tree[6];
        sprime2 = tree6;
      }else{
        tree = buildtree(zpos, spos, logu, v, j - 1, eps, R, tau, gaussmat, dyads, deltamax);
        arma::mat tree2 = tree[2];
        zpos = tree2;
        arma::mat tree3 = tree[3];
        spos = tree3;
        arma::mat tree4 = tree[4];
        double tree5 = tree[5];
        double tree6 = tree[6];
        zprime2 = tree4;
        nprime2 = tree5;
        sprime2 = tree6;
      }
      if(runif() < (nprime2/(nprime2 + nprime))){
        zprime = zprime2;
      }
      nprime = nprime + nprime2;
      double prod1 = sum(sum((zpos - zneg) % sneg));
      double prod2 = sum(sum((zpos - zneg) % spos));
      if(prod1 >= 0){
        if(prod2 >= 0){
          sprime = sprime2;
        }else{
          sprime = 0;
        }
      }else{
        sprime = 0;
      }
    }
    return(List::create(zneg, sneg, zpos, spos, zprime, nprime, sprime));
  }
}

arma::mat nuts(arma::mat z, double eps, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax){
  int n = z.n_rows;
  int d = z.n_cols;
  arma::mat R = arma::chol(gaussmat);
  arma::mat s0 = rmvnorm_precchol(d, n, R);
  // calculate the slice variable
  arma::mat mom_post(1,1);
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_post = mom_post + ((s0.col(i)).t()) * gaussmat * (s0.col(i));
  }
  double logu = log(runif()) + ld_all_categorical(z, dyads, 1.0, tau, gaussmat) - 0.5 * mom_post(0,0);
  arma::mat zneg = z;
  arma::mat zpos = z;
  arma::mat sneg = s0;
  arma::mat spos = s0;
  double j = 0;
  arma::mat znew = z;
  double nn = 1.0;
  double ss = 1.0;
  arma::mat zprime;
  double nprime;
  double sprime;
  while(ss == 1){
    double v = -1 + 2 * floor(2 * runif());
    if(v == -1){
      List tree = buildtree(zneg, sneg, logu, v, j, eps, R, tau, gaussmat, dyads, deltamax);
      arma::mat tree0 = tree[0];
      zneg = tree0;
      arma::mat tree1 = tree[1];
      sneg = tree1;
      arma::mat tree4 = tree[4];
      zprime = tree4;
      double tree5 = tree[5];
      nprime = tree5;
      double tree6 = tree[6];
      sprime = tree6;
    }else{
      List tree = buildtree(zpos, spos, logu, v, j, eps, R, tau, gaussmat, dyads, deltamax);
      arma::mat tree2 = tree[2];
      zpos = tree2;
      arma::mat tree3 = tree[3];
      spos = tree3;
      arma::mat tree4 = tree[4];
      double tree5 = tree[5];
      double tree6 = tree[6];
      zprime = tree4;
      nprime = tree5;
      sprime = tree6;
    }
    if(sprime == 1){
      if(runif() < (nprime/nn)){
        znew = zprime;
      }
    }
    nn = nn + nprime;
    j = j + 1;
    double prod1 = sum(sum((zpos - zneg) % sneg));
    double prod2 = sum(sum((zpos - zneg) % spos));
    if(prod1 >= 0){
      if(prod2 >= 0){
        ss = sprime;
      }
      else{
        ss = 0;
      }
    }else{
      ss = 0;
    }
  }
  return(znew);
}

arma::mat nutsR(arma::mat z, double eps, arma::vec tau, arma::mat gaussmat, arma::mat dyads, double deltamax, arma::mat R){
  int n = z.n_rows;
  int d = z.n_cols;
  arma::mat s0 = rmvnorm_precchol(d, n, R);
  // calculate the slice variable
  arma::mat mom_post(1,1);
  mom_post(0,0) = 0;
  for(int i = 0; i < d; ++i){
    mom_post = mom_post + ((s0.col(i)).t()) * gaussmat * (s0.col(i));
  }
  double logu = log(runif()) + ld_all_categorical(z, dyads, 1.0, tau, gaussmat) - 0.5 * mom_post(0,0);
  arma::mat zneg = z;
  arma::mat zpos = z;
  arma::mat sneg = s0;
  arma::mat spos = s0;
  double j = 0;
  arma::mat znew = z;
  double nn = 1.0;
  double ss = 1.0;
  arma::mat zprime;
  double nprime;
  double sprime;
  while(ss == 1){
    double v = -1 + 2 * floor(2 * runif());
    if(v == -1){
      List tree = buildtree(zneg, sneg, logu, v, j, eps, R, tau, gaussmat, dyads, deltamax);
      arma::mat tree0 = tree[0];
      zneg = tree0;
      arma::mat tree1 = tree[1];
      sneg = tree1;
      arma::mat tree4 = tree[4];
      zprime = tree4;
      double tree5 = tree[5];
      nprime = tree5;
      double tree6 = tree[6];
      sprime = tree6;
    }else{
      List tree = buildtree(zpos, spos, logu, v, j, eps, R, tau, gaussmat, dyads, deltamax);
      arma::mat tree2 = tree[2];
      zpos = tree2;
      arma::mat tree3 = tree[3];
      spos = tree3;
      arma::mat tree4 = tree[4];
      double tree5 = tree[5];
      double tree6 = tree[6];
      zprime = tree4;
      nprime = tree5;
      sprime = tree6;
    }
    if(sprime == 1){
      if(runif() < (nprime/nn)){
        znew = zprime;
      }
    }
    nn = nn + nprime;
    j = j + 1;
    double prod1 = sum(sum((zpos - zneg) % sneg));
    double prod2 = sum(sum((zpos - zneg) % spos));
    if(prod1 >= 0){
      if(prod2 >= 0){
        ss = sprime;
      }
      else{
        ss = 0;
      }
    }else{
      ss = 0;
    }
  }
  return(znew);
}

