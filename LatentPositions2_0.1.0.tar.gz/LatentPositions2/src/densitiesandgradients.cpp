#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "densitiesandgradients.h"
#include "helperobjects.h"

using namespace Rcpp;

// the non-gaussian part of the targetted density
// [[Rcpp::export]]
double ld_nogaussian(arma::mat z, arma::mat dyads, double gamma2, double tau){

  // save time by pre-computing the squares (I assume we use each at least once)
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;

  double result = 0;
  for(int i = 0; i < ndyads; ++i){
    result += log(1 - tau * exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1))))));
  }
  return(result);
}

// the non-gaussian part of the targetted density
// [[Rcpp::export]]
double ld_nogaussian_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau){

  // save time by pre-computing the squares (I assume we use each at least once)
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;

  double result = 0;
  for(int i = 0; i < ndyads; ++i){
    result += log(1 - tau[dyads(i,2)] * exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1))))));
  }
  return(result);
}

// the gaussian part of the targetted density
// [[Rcpp::export]]
double ld_gaussian(arma::mat z, arma::mat gaussmat){
  arma::mat zzt = z * z.t();
  int n = z.n_rows;
  double res = 0;
  for(int i = 0; i < n; ++i)
  {
    res += dot(zzt.row(i), gaussmat.col(i));
  }
  res = -res/2.0;
  return(res);
}

// the targetted density
// [[Rcpp::export]]
double ld_all(arma::mat z, arma::mat dyads, double gamma2, double tau, arma::mat gaussmat){
  return(ld_gaussian(z, gaussmat) + ld_nogaussian(z, dyads, gamma2, tau));
}

// the targetted density
// [[Rcpp::export]]
double ld_all_categorical(arma::mat z, arma::mat dyads, double gamma2, arma::vec tau, arma::mat gaussmat){
  return(ld_gaussian(z, gaussmat) + ld_nogaussian_categorical(z, dyads, gamma2, tau));
}

// the targetted density
// [[Rcpp::export]]
double ld_logistic(arma::mat z, arma::mat A, arma::mat priormat){
  double res = 0;
  int n = z.n_rows;
  arma::mat zzt = z * z.t();
  for(int i = 0; i < n; ++i)
  {
    res += dot(zzt.row(i), priormat.col(i));
  }
  res = -res/2.0;

  arma::colvec squares = sum(square(z), 1);
  for(int i = 0; i < n; ++i){
    for(int j = 0; j < i; ++j){
      if(A(i,j) == 0){
        res -= log(1.0 + exp(- sqrt(squares(i) + squares(j) - 2 * dot(z.row(i), z.row(j)) )));
      }
      if(A(i,j) == 1){
        res -= log(1.0 + exp(sqrt(squares(i) + squares(j) - 2 * dot(z.row(i), z.row(j)) )));
      }
    }
  }
  return(res);
}

// Calculate the gradient of the non-gaussian part.
// [[Rcpp::export]]
arma::mat gradient_nogaussian(arma::mat z_, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              double tau // the probability of an edge at distance 0
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  int ndyads = dyads.n_rows;
  arma::mat ret(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> z(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> squares(nnodes, 1);

  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      z(i,j) = z_(i,j);
    }
    squares(i, 0) = (z.row(i)).dot(z.row(i));
  }

  stan::math::var lp = 0;
  // for(int i = 0; i < ndyads; ++i){
  //     lp -= log(1 - tau * exp(-(z.row(dyads(i, 1)) - z.row(dyads(i, 2))).dot((z.row(dyads(i, 1)) - z.row(dyads(i, 2))))/(2 * gamma2)));
  // }

  for(int i = 0; i < ndyads; ++i){
    lp -= log(1 - tau * exp(- 0.5/gamma2 * ( squares(dyads(i, 0), 0) + squares(dyads(i, 1), 0) - 2 * (z.row(dyads(i, 0))).dot(z.row(dyads(i, 1))))));
  }

  lp.grad();
  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      ret(i,j) = z(i,j).adj();
    }
  }

  // Memory is allocated on a global stack
  stan::math::recover_memory();
  //stan::math::ChainableStack::memalloc_.free_all();

  return ret;
}

// Calculate the gradient of the non-gaussian part.
// [[Rcpp::export]]
arma::mat gradient_nogaussian_categorical(arma::mat z_, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              arma::vec tau // the probability of an edge at distance 0
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  int ndyads = dyads.n_rows;
  arma::mat ret(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> z(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> squares(nnodes, 1);

  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      z(i,j) = z_(i,j);
    }
    squares(i, 0) = (z.row(i)).dot(z.row(i));
  }

  stan::math::var lp = 0;

  for(int i = 0; i < ndyads; ++i){
    lp -= log(1 - tau[dyads(i, 2)] * exp(- 0.5/gamma2 * ( squares(dyads(i, 0), 0) + squares(dyads(i, 1), 0) - 2 * (z.row(dyads(i, 0))).dot(z.row(dyads(i, 1))))));
  }

  lp.grad();
  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      ret(i,j) = z(i,j).adj();
    }
  }

  // Memory is allocated on a global stack
  stan::math::recover_memory();
  //stan::math::ChainableStack::memalloc_.free_all();

  return ret;
}


// [[Rcpp::export]]
arma::mat gradient_all(arma::mat z_, // the latent positions
                              arma::mat dyads, // the dyads without edges to consider
                              double gamma2, // the variance of the link function
                              double tau, // the probability of an edge at distance 0
                              arma::mat gaussmat
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  arma::mat ret(nnodes, d);

  ret = gradient_nogaussian(z_, dyads, gamma2, tau);

  // add gaussian part
  ret = ret + gaussmat * z_;

  return ret;
}

// [[Rcpp::export]]
arma::mat gradient_all_categorical(arma::mat z_, // the latent positions
                       arma::mat dyads, // the dyads without edges to consider
                       double gamma2, // the variance of the link function
                       arma::vec tau, // the probability of an edge at distance 0
                       arma::mat gaussmat
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  arma::mat ret(nnodes, d);

  ret = gradient_nogaussian_categorical(z_, dyads, gamma2, tau);

  // add gaussian part
  ret = ret + gaussmat * z_;

  return ret;
}

// Calculate the gradient of the non-gaussian part.
// [[Rcpp::export]]
arma::mat gradient_logistic(arma::mat z_, // the latent positions
                       arma::mat A,  // the dyads without edges to consider
                       arma::mat priormat // to encode the prior information
) {
  int nnodes = z_.n_rows;
  int d = z_.n_cols;
  arma::mat ret(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> z(nnodes, d);
  Eigen::Matrix<stan::math::var, Eigen::Dynamic, Eigen::Dynamic> squares(nnodes, 1);

  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      z(i,j) = z_(i,j);
    }
    squares(i, 0) = (z.row(i)).dot(z.row(i));
  }

  stan::math::var lp = 0;

  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < i; ++j){
      if(A(i,j) == 0){
        lp += log(1.0 + exp(- sqrt(squares(i) + squares(j) - 2 * ((z.row(i)).dot(z.row(j)) ))));
      }
      if(A(i,j) == 1){
        lp += log(1.0 + exp(sqrt(squares(i) + squares(j) - 2 * ((z.row(i)).dot(z.row(j)) ))));
      }
    }
  }


  lp.grad();
  for(int i = 0; i < nnodes; ++i){
    for(int j = 0; j < d; ++j){
      ret(i,j) = z(i,j).adj();
    }
  }

  // Memory is allocated on a global stack
  stan::math::recover_memory();

  ret = ret + priormat * z_;
  return ret;
}

// [[Rcpp::export]]
arma::mat MLE_initialize2(arma::mat A,
                     arma::mat Alabels,
                     arma::mat prior,
                    arma::mat z_init,
                    arma::vec tau,
                    double sigma2inv,
                    double eps = 0.01,
                    int niterations = 100
) {
  int ntaus = tau.size(); // the number of unique categories
  int n = z_init.n_rows; // the number of nodes
  int d = z_init.n_cols; // the dimension of the latent positions
  arma::mat z = z_init; // initialize the z matrix
  arma::mat Laplacian = getLaplacian(A);

  // create stuff needed to work with dyads
  List ret = getdyadsmat(Alabels, A, ntaus);
  arma::mat dyads = ret[0]; // holds the endpoints for each non-edge dyad and its category.
  int ndyads = dyads.n_rows; // the number of dyads
  arma::mat gaussmat = Laplacian + sigma2inv * prior;
  for(int i = 0; i < niterations; i++){
    z = z - eps* gradient_all_categorical(z, dyads, 1.0, tau, gaussmat);
    double ll2 = ld_all_categorical(z, dyads, 1.0, tau, gaussmat);
  }
  return z;
}

//the prior on sigma2inv
// [[Rcpp::export]]
double ld_sigma2inv(double sigma2inv, double param1, double param2){
  double lsigma2inv = (param1 - 1) * log(sigma2inv) - param2 * sigma2inv;
  return(lsigma2inv);
}

// the prior on tau
double ld_tau(arma::vec tau, arma::vec beta1, arma::vec beta2){
  double ltau = 0;
  for(int i = 0; i < tau.size(); ++i){
    ltau = ltau + (beta1[i] - 1) * log(tau[i]) + (beta2[i] - 1) * log(1 - tau[i]);
  }
  return(ltau);
}

// the density of theta given tau
// // [[Rcpp::export]]
double ld_theta(arma::vec tau, arma::vec nthetas0cat, arma::vec nthetas1cat){
  double ltheta = 0;
  for(int i = 0; i < tau.size(); ++i){
    ltheta += log(tau[i]) * nthetas1cat[i] + log(1 - tau[i]) * nthetas0cat[i];
  }
  return(ltheta);
}
