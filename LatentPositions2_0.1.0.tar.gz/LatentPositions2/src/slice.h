#ifndef slice_h
#define slice_h
#include <RcppArmadillo.h>
#include "common.h"
#include "rng.h"
#include "densitiesandgradients.h" //contains ld_nogaussian

// defining density for vanilla slice sampler
class logdensity {
public:
  virtual double val(double y) = 0;
};

// defining density for elliptical slice sampler
class logdensityellipse{
public:
  virtual double val(arma::vec y) = 0;
};

// defining density for elliptical slice sampler on iid vectors as a matrix
class logdensityellipsemat{
public:
  virtual double val(arma::mat y) = 0;
};

// defining elliptical slice for ESS within Gibbs
class logdensityellipseGibbs{
public:
  virtual double val(arma::mat y) = 0;
};

// for elliptical slice within Gibbs and Firefly
class ld_zGibbs: public logdensityellipseGibbs {
public:
  int i;
  arma::mat disconnecteds;
  int disconnectednum;
  arma::mat disconnectedthetaindices;
  arma::vec theta;
  double sigma2inv;
  double sigma2inv_init;
  arma::mat priorconnecteds;
  arma::vec priorconnectednums;
  arma::mat priorprecision;

  double val(arma::mat z) {
    double square = dot(z.row(i), z.row(i));
    double res = 0;
    for(int j = 0; j < disconnectednum; ++j){
      if(theta(disconnectedthetaindices(i, j)) == 1){
        res += log(1.0 - exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
      }
    }
    return(res);
    //Note this does *not* need to return normalized densities
  }
  ld_zGibbs(int i_, arma::mat disconnecteds_, int disconnectednum_, arma::mat disconnectedthetaindices_, arma::vec theta_, double sigma2inv_, double sigma2inv_init_, arma::mat priorconnecteds_, arma::vec priorconnectednums_, arma::mat priorprecision_){i = i_; disconnecteds =  disconnecteds_; disconnectednum = disconnectednum_; disconnectedthetaindices = disconnectedthetaindices_; theta = theta_; sigma2inv = sigma2inv_; sigma2inv_init = sigma2inv_init_; priorconnecteds = priorconnecteds_; priorconnectednums = priorconnectednums_; priorprecision = priorprecision_;}
};

// for elliptical slice within Gibbs without firefly
class ld_zGibbsnoFF: public logdensityellipseGibbs {
public:
  int i;
  arma::mat disconnecteds;
  arma::mat Alabels;
  int disconnectednum;
  arma::vec tau;
  double sigma2inv;
  double sigma2inv_init;
  arma::mat priorconnecteds;
  arma::vec priorconnectednums;
  arma::mat priorprecision;

  double val(arma::mat z) {
    double square = dot(z.row(i), z.row(i));
    double res = 0;

    for(int j = 0; j < disconnectednum; ++j){
      res += log(1.0 - tau[Alabels(i, disconnecteds(i,j))] * exp(-0.5 * (square + dot(z.row(disconnecteds(i,j)), z.row(disconnecteds(i,j))) - 2.0 * dot(z.row(disconnecteds(i,j)), z.row(i)))));
    }
    return(res);
    //Note this does *not* need to return normalized densities
  }
  ld_zGibbsnoFF(int i_, arma::mat disconnecteds_, int disconnectednum_, arma::vec tau_, double sigma2inv_, double sigma2inv_init_, arma::mat priorconnecteds_, arma::vec priorconnectednums_, arma::mat priorprecision_, arma::mat Alabels_){i = i_; disconnecteds =  disconnecteds_; disconnectednum = disconnectednum_; tau = tau_; sigma2inv = sigma2inv_; sigma2inv_init = sigma2inv_init_; priorconnecteds = priorconnecteds_; priorconnectednums = priorconnectednums_; priorprecision = priorprecision_; Alabels = Alabels_;}
};

// for elliptical slice as a matrix
class ld_zz: public logdensityellipsemat {
public:
  arma::mat dyads2;
  arma::vec tau;
  double gamma2;

  double val(arma::mat Z) {
    double res = ld_nogaussian_categorical(Z, dyads2, gamma2, tau);
    return(res);
    //Note this does *not* need to return normalized densities
  }
  ld_zz(arma::mat dyads2_, arma::vec tau_, double gamma2_){dyads2=dyads2_; tau = tau_; gamma2 = gamma2_;}
};

// slice sampler implementation from Jared Murray's shared code.
double slice(double x0,              // the initial point; use the current value of the mcmc chain
             logdensity* g,          // The log of the possibly unnormalized density
             double w=1.,            // The stepping out window (see Neal 2003)
             double m=INFINITY,      // The max number of times to step out, inf is only safe if bounded
             double lower=-INFINITY, // lower bound of the density
             double upper=INFINITY   // upper bound of the density
);

arma::vec ellipticalslice(arma::vec f,              // the initial point; use the current value of the mcmc chain
                          arma::mat Sigma,    // the precision matrix
                          int n,    // the dimension of f
                          logdensityellipse* logL
);

arma::mat ellipticalslicemat(arma::mat Z,              // the initial point; use the current value of the mcmc chain
                          arma::mat Sigma,    // the precision matrix
                          int n,    // the dimension of f
                          int d,
                          logdensityellipsemat* logL
);

arma::mat ellipticalsliceGibbs(arma::mat Z, int i, arma::vec meani, double vari, int d, logdensityellipseGibbs* logL);

#endif
