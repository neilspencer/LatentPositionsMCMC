#include <RcppArmadillo.h>
using namespace Rcpp;

// note: If this doesn't work for old code, it is because i switched the order of the cube from nruns first to nruns last

// [[Rcpp::export]]
NumericMatrix getdistances(NumericVector innodes, NumericVector outnodes, arma::cube zs, int nruns, int nbenches, int d) {
  NumericMatrix distances(nbenches, nruns);
  for(int i = 0; i < nbenches; ++i){
    for(int j = 0; j < nruns; ++j){
      for(int k = 0; k < d; ++k){
        distances(i, j) += (zs(innodes[i] - 1, k, j) - zs(outnodes[i] - 1, k, j)) * (zs(innodes[i] - 1, k, j) - zs(outnodes[i] - 1, k, j));
      }
    }
  }
  return(distances);
}


