#include <RcppArmadillo.h>
#include "rng.h"
#include "firefly.h"

using namespace Rcpp;

arma::vec update_thetas(arma::vec thetas, arma::mat z, arma::mat dyads, double gamma2, double tau){
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;
  for(int i = 0; i < ndyads; ++i){
    if(thetas(i) == 0){ // if latent starts at 0
      if(runif() < tau){ // if MH proposes a move to 1
        if(runif() > exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1)))))){ // checking if move is accepted
          thetas(i) = 1;
        }
      }
    }else{ // if latent starts at 0
      if(runif() > tau){ // if MH proposes a move to 0
        thetas(i) = 0;
      }
    }
  }
  return(thetas);
}

arma::vec update_thetas_categorical(arma::vec thetas, arma::mat z, arma::mat dyads, double gamma2, arma::vec tau){
  arma::colvec squares = sum(square(z), 1);
  int ndyads = dyads.n_rows;
  for(int i = 0; i < ndyads; ++i){
    if(thetas(i) == 0){ // if latent starts at 0
      if(runif() < tau[dyads(i, 2)]){ // if MH proposes a move to 1
        if(runif() > exp(- 0.5/gamma2 * (squares(dyads(i, 0)) + squares(dyads(i, 1)) - 2 * dot(z.row(dyads(i, 0)), z.row(dyads(i, 1)))))){ // checking if move is accepted
          thetas(i) = 1;
        }
      }
    }else{ // if latent starts at 0
      if(runif() > tau[dyads(i, 2)]){ // if MH proposes a move to 0
        thetas(i) = 0;
      }
    }
  }
  return(thetas);
}





