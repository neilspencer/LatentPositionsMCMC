#ifndef helperobjects_h
#define helperobjects_h
#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"
#include "slice.h"
using namespace Rcpp;
arma::mat getLaplacian(arma::mat A);
arma::mat priorMatrix_temporal(int nnodes, int ntimes, double rho);
List getdyadsmat(arma::mat Alabels, arma::mat A, int ntaus);
List getGibbsObjects(arma::mat A, arma::mat Alabels, arma::mat gaussmat);
arma::mat createdisconnectedindices(arma::mat disconnecteds, arma::vec disconnectednums, arma::mat dyads);
#endif
