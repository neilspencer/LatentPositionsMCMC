#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "mcmchelpers.h"

using namespace Rcpp;

// regular HMC (with good Mass matrix)
// [[Rcpp::export]]
List HMC_logistic(arma::mat z, arma::mat A, arma::mat gaussmat, arma::mat gaussmat_inv,
                          double eps, int L, int nruns, arma::mat priormat
){

  int n = z.n_rows;
  int d = z.n_cols;

  //std::vector<arma::mat> zs;
  arma::cube zs(n, d, nruns);
  std::vector<double> accepts;

  double pdf_old = ld_logistic(z, A, priormat);

  for(int run = 0; run < nruns; ++run){
    Rcpp::Rcout << run << std::endl;
    arma::mat s0 = rmvnorm_prec(d, n, gaussmat_inv);

    // beginning leapfrog step
    arma::mat znew = z;
    arma::mat snew = s0 - eps/2 * (gradient_logistic(znew, A, priormat));

    for(int step = 0; step < L; ++step){

      znew = znew + eps * gaussmat_inv * snew;

      // update momentum
      if(step != (L - 1)){
        snew = snew - eps * (gradient_logistic(znew, A, priormat));
      }
    }

    //final partial momentum update
    snew = snew - eps/2 * (gradient_logistic(znew, A, priormat));

    // calculate the metropolis hastings ratio
    double pdf =  ld_logistic(znew, A, priormat);

    arma::mat mom_pre(1,1);
    arma::mat mom_post(1,1);

    mom_pre(0,0) = 0;
    mom_post(0,0) = 0;
    for(int i = 0; i < d; ++i){
      mom_pre = mom_pre + ((s0.col(i)).t()) * gaussmat_inv * (s0.col(i));
      mom_post = mom_post + ((snew.col(i)).t()) * gaussmat_inv * (snew.col(i));
    }

    double MH =  pdf - 0.5 * mom_post(0,0) - pdf_old + 0.5 * mom_pre(0,0);
    Rcpp::Rcout << exp(MH) << std::endl;
    if(MH > log(R::runif(0,1))){
      accepts.push_back(1);
      zs.slice(run) = znew;
      z = znew;
      pdf_old = pdf;
      Rcpp::Rcout << "accept " << std::endl;
    }
    else{
      accepts.push_back(0);
      zs.slice(run) = z;
      Rcpp::Rcout << "reject " << std::endl;
    }

  }
  return(List::create(_["accepts"]= accepts, _["z"]= zs));
}

// [[Rcpp::export]]
List MCMC_logistic(arma::mat z, arma::mat connecteds, NumericVector connectednums, arma::mat disconnecteds, NumericVector disconnectednums, arma::mat lineage, double sigma2, double delta2,
                   double alpha, double rwsd, int nruns
){

  int n = z.n_rows;
  int d = z.n_cols;

  arma::cube zs(n, d, nruns);
  arma::mat accepts(nruns, n);

  for(int run = 0; run < nruns; ++run){
    Rcpp::Rcout << run << std::endl;
    arma::mat noise(n, d);
    for(int i = 0; i < d; ++i){
      noise.col(i) = rwsd * as<arma::vec>(rnorm(n));
    }
    for(int step = 0; step < n; ++step){
      arma::mat znew = z;
      znew.row(step) += noise.row(step);
      double MH = ldrow_logistic(step, znew, connecteds, connectednums[step], disconnecteds, disconnectednums[step], lineage, sigma2, delta2, alpha) - ldrow_logistic(step, z, connecteds, connectednums[step], disconnecteds, disconnectednums[step], lineage, sigma2, delta2, alpha);
      if(log(R::runif(0,1)) < MH){
        z.row(step) = znew.row(step);
        accepts(run, step) = 1;
      }
      else{
        accepts(run, step) = 0;
      }
    }
    zs.slice(run) = z;
  }
  return(List::create(_["accepts"]= accepts, _["z"]= zs));
}
