#include <RcppArmadillo.h>
#include <stan/math.hpp>
#include "rng.h"
#include "densitiesandgradients.h"
#include "firefly.h"
#include "mcmchelpers.h"

using namespace Rcpp;

// calculate the graph Laplacian
// [[Rcpp::export]]
arma::mat getLaplacian(arma::mat A){
  return(diagmat(sum(A)) - A);
}

// calculate the prior matrix corresponding to a temporal graph
// [[Rcpp::export]]
arma::mat priorMatrix_temporal(int nnodes, int ntimes, double rho){
  arma::mat result(nnodes * ntimes, nnodes * ntimes, fill::eye);
  if(ntimes == 1){
    return(result);
  }
  for(int i = nnodes; i < nnodes * (ntimes - 1); ++i){
    result(i,i) = result(i,i) + rho * rho;
  }
  for(int i = 0; i < nnodes; ++i){
    for(int j = 1; j < ntimes; ++j){
      result(i + (j - 1) * nnodes, i + j * nnodes) = -1.0 * rho;
      result(i + j * nnodes, i + (j - 1) * nnodes) = -1.0 * rho;
    }
  }
  return(result * (1/(1- rho * rho)));
}

// Obtains the necessary quantities related to the dyads from A and Alabels.
// note that -1 in Alabels indicates a missing value
// [[Rcpp::export]]
List getdyadsmat(arma::mat Alabels, arma::mat A, int ntaus){
  uvec inds = find(Alabels > -1);
  int ndyads = (inds.size() - sum(sum(A)))/2;
  arma::mat dyads(ndyads, 3);
  arma::vec nedges_categories(ntaus);
  arma::vec ndyadsincat(ntaus);
  std::vector<arma::uvec> dyadids;

  nedges_categories.zeros();
  int k = 0;
  for(int i = 0; i < Alabels.n_rows; ++i){
    for(int j = 0; j < i; ++j){
      if(Alabels(i,j) >= 0){
        if(A(i, j) == 1){
          nedges_categories[Alabels(i,j)]++;
        }else{
          dyads(k, 0) = i;
          dyads(k, 1) = j;
          dyads(k, 2) = Alabels(i,j);
          k++;
        }
      }
    }
  }
  // filling the above objects
  for(int i = 0; i < ntaus; ++i){
    arma::uvec ids = find(dyads.col(2) == i); // find dyads in category i
    ndyadsincat[i] = ids.size(); // count how many there are
    dyadids.push_back(ids); // store them
  }
  return(List::create(_["dyads"]=dyads, _["dyadids"]=dyadids, _["ndyadsincat"]=ndyadsincat, _["nedges_categories"]=nedges_categories));
}

// [[Rcpp::export]]
List getGibbsObjects(arma::mat A, arma::mat Alabels, arma::mat gaussmat){
  int n = A.n_rows;
  arma::mat connecteds(n, n - 1, fill::ones);
  arma::mat disconnecteds(n, n - 1, fill::ones);
  connecteds = -1 * connecteds;
  disconnecteds = -1 * disconnecteds;
  arma::vec connectednums(n);
  arma::vec disconnectednums(n);
  for(int i = 0; i < n; ++i){
    int a1 = 0;
    int a2 = 0;
    for(int j = 0; j < n; ++j){
      if(Alabels(i,j) > -1){
        if(A(i,j) == 0){
          disconnecteds(i, a2) = j;
          a2++;
        }
      }
      if(gaussmat(i,j) != 0){
        connecteds(i, a1) = j;
        a1++;
      }
    }
    connectednums[i] = a1;
    disconnectednums[i] = a2;
  }
  return(List::create(_["connecteds"]= connecteds, _["disconnecteds"]= disconnecteds, _["connectednums"]= connectednums, _["disconnectednums"]= disconnectednums));
}

// [[Rcpp::export]]
arma::mat createdisconnectedindices(arma::mat disconnecteds, arma::vec disconnectednums, arma::mat dyads){
  arma::mat disconnectedindices = disconnecteds;
  for(int i = 0; i < dyads.n_rows; ++i){
    int done = 0;
    int firstone;
    int secondone;
    while(done >= 0){
      if(disconnecteds(dyads(i,0), done) == dyads(i,1)){
        firstone = done;
        done = -1;
      }
      else{
        done++;
      }
    }
    done = 0;
    while(done >= 0){
      if(disconnecteds(dyads(i,1), done) == dyads(i,0)){
        secondone = done;
        done = -1;
      }
      else{
        done++;
      }
    }
    disconnectedindices(dyads(i,0), firstone) = i;
    disconnectedindices(dyads(i,1), secondone) = i;
  }
  return(disconnectedindices);
}
